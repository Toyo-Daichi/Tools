## 各ディレクトリとの同期

````
Local:
  rsync -av -e from_directory to_directory

SSH (config):
  sync -av -e ssh __Host:from_directory to_directory
```
