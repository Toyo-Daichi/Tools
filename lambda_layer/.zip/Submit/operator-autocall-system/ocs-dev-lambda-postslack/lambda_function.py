import os
import logging
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

# config
client = WebClient(token=os.environ['SLACK_TOKEN'])
logger = logging.getLogger(__name__)
channel_id = os.environ['SLACK_CHANNEL']

def lambda_handler(event, context):
  try:
    #if event['status'] == 'None':
    #  msg = '{}アラートです。担当者が手配されていません。'.format(event["service"])
    #  submit = "<!here>\n" + msg
    #else:
    #msg = '{}アラートです。担当者{}が対応します'.format(event['service'], event['status'])
    msg = '{}です。担当者xxx(未実装)が手配されました。'.format(event['alertTypePronunciation'])
    submit = msg
        
    result = client.chat_postMessage(
        channel=channel_id,
        text= submit,
    )
    logger.info(result)
  
  except SlackApiError as e:
      logger.error(f"Error posting message: {e}")