#!/bin/sh
# Created on 2021.8.24
# Upload CloudShell
# or
# $ alias aws='docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli'

#set -x

#----------------------------------------------------------------------
# +++ Set configure
#----------------------------------------------------------------------
from_region="us-east-1"
to_region="ap-northeast-1"

# cp status
sysname="ocs"
env="dev"
type="dynamo"
uses=("configuration" "valve" "bodykeyword")

# original table name
org_tables=("connect_conf" "connect_valve" "connect_body_keyword")

#----------------------------------------------------------------------
# +++ Copy dynamoDB
#----------------------------------------------------------------------
get_table_data() {
  aws dynamodb describe-table --table-name ${org_table_name} --region ${from_region} > ${org_table_file}

  cat ${org_table_file} |
  jq '.Table' |
  jq '.TableName = "'${new_table_name}'"' |
  jq '.ProvisionedThroughput.ReadCapacityUnits |= 1' |
  jq '.ProvisionedThroughput.WriteCapacityUnits |= 1' |
  jq 'del(.TableStatus)' |
  jq 'del(.CreationDateTime)' |
  jq 'del(.ProvisionedThroughput.LastIncreaseDateTime)' |
  jq 'del(.ProvisionedThroughput.NumberOfDecreasesToday)' |
  jq 'del(.TableSizeBytes)' |
  jq 'del(.ItemCount)' |
  jq 'del(.TableArn)' |
  jq 'del(.TableId)' |
  jq 'del(.LatestStreamLabel)' |
  jq 'del(.LatestStreamArn)' |
  jq 'del(.GlobalSecondaryIndexes[]?.IndexStatus)' |
  jq 'del(.GlobalSecondaryIndexes[]?.IndexSizeBytes)' |
  jq 'del(.GlobalSecondaryIndexes[]?.ItemCount)' |
  jq 'del(.GlobalSecondaryIndexes[]?.IndexArn)' |
  jq 'del(.GlobalSecondaryIndexes[]?.ProvisionedThroughput.NumberOfDecreasesToday)' |
  jq 'del(.BillingModeSummary)' > ${new_table_file}

}

create_table() {
  aws dynamodb create-table --cli-input-json file://${new_table_file} --region ${to_region}
  sleep 10s
}

get_items_data() {
  aws dynamodb scan --table-name ${org_table_name} --region ${from_region} > ${org_items_file}
}

put_items() {
  item_length=$(cat ${org_items_file} | jq ".Items | length")

  if [ ${item_length} -gt 0 ]; then
    imax=`expr ${item_length} - 1`
    for i in `seq 0 ${imax}`; do
      item=`cat ${org_items_file} | jq ".Items[${i}]"`
      aws dynamodb put-item --table-name ${new_table_name} --item "${item}" --region ${to_region}
    done
  fi
}

#----------------------------------------------------------------------
# +++ Execution
#----------------------------------------------------------------------
index=0
for table_name in ${org_tables[@]}; do

  org_table_name=${table_name}
  new_table_name=${sysname}-${env}-${type}-${uses[${index}]}
  
  #
  org_table_file=${org_table_name}.json
  new_table_file=${new_table_name}.json
  org_items_file=org_items_${org_table_name}.json

  #
  get_table_data
  create_table
  get_items_data
  put_items

  index=`expr ${index} + 1`
done

echo 'Normal END'

exit
