#!/bin/sh
# Created on 2021.8.26
# Upload CloudShell
# or
alias aws='docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli'
aws_relative_path='Call/ocs-dev-cli'

#set -x

#----------------------------------------------------------------------
# +++ Set configure
#----------------------------------------------------------------------
sysname="ocs"
env="dev"
type="s3"
use="configuration"
#
backet_name=${sysname}-${env}-${type}-${use}

# prefix name
prefix_ses="INBOX"

#----------------------------------------------------------------------
# +++ s3 func. 
#----------------------------------------------------------------------
upload_file(){
  aws s3 sync $1 s3://$2 --include '*' --acl public-read 
}

#----------------------------------------------------------------------
# +++ Execution
#----------------------------------------------------------------------
random_str=`head -c 10 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | cut -c 1-10`
cp `pwd`/test/test-trigger.txt `pwd`/test/test-trigger-${random_str}.txt
upload_file ${aws_relative_path}/test ${backet_name}/${prefix_ses}

rm `pwd`/test/test-trigger-${random_str}.txt
echo 'Normal END'

exit
