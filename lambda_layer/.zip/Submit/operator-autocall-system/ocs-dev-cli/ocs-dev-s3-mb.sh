#!/bin/sh
# Created on 2021.8.24
# Upload CloudShell
# or
alias aws='docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli'
aws_relative_path='Call/ocs-dev-cli'

#set -x

#----------------------------------------------------------------------
# +++ Set configure
#----------------------------------------------------------------------
sysname="ocs"
env="dev"
type="s3"
use="configuration"
#
backet_name=${sysname}-${env}-${type}-${use}

# prefix name
prefix_ses="INBOX"
prefix_call_content="Prompt"
prefix_dynamo_mantenance="dynamodb_maintenance/scan_data"
#
prefixes=(${prefix_ses} ${prefix_call_content} ${prefix_dynamo_mantenance})

#----------------------------------------------------------------------
# +++ s3 func. 
#----------------------------------------------------------------------
make_backet(){
  aws s3 mb s3://$1
}

upload_file(){
  aws s3 sync $1 s3://$2 --include '*' --acl public-read 
}

sync_backet(){
  aws s3 sync s3://$1 s3://$2 --include '*' --acl private
}

put_backet_public_access(){
  aws s3api put-public-access-block --bucket $1 --public-access-block-configuration \
    "BlockPublicAcls=true, IgnorePublicAcls=true, BlockPublicPolicy=true, RestrictPublicBuckets=true"
}

put_backet_policy(){
  aws s3api put-bucket-policy --bucket $1 --policy file://$2
}

#----------------------------------------------------------------------
# +++ Execution
#----------------------------------------------------------------------
make_backet ${backet_name}
for prefix in ${prefixes[@]}; do
  mkdir -p `pwd`/work/${prefix}
  touch `pwd`/work/${prefix}/test.txt
done

upload_file ${aws_relative_path}/work ${backet_name}
sync_backet configuration-for-connect/${prefix_call_content} ${backet_name}/${prefix_call_content}

cat << EOF > `pwd`/work/${backet_name}.json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "AllowSESPuts",
      "Effect": "Allow",
      "Principal": {
        "Service": "ses.amazonaws.com"
      },
      "Action": "s3:PutObject",
      "Resource": "arn:aws:s3:::${backet_name}/*",
      "Condition": {
        "StringEquals": {
            "aws:Referer": "${AWS_ACCOUNT_ID}"
        }
      }
    }
  ]
}
EOF

put_backet_public_access ${backet_name}
put_backet_policy ${backet_name} ${aws_relative_path}/work/${backet_name}.json

rm -rf `pwd`/work/*

echo 'Normal END'

exit
