## 環境準備

- 鍵の作成  
```
cd .ssh
ssh-keygen
cat ~/.ssh/id_rsa.pub
```
- profile > Setting > SSH and GPG keys に移動

- Githubに公開鍵を登録  

- SSOを有効化

- レポジトリをクローンする
```
git clone git@github.com:ntteast-cnw/operator-autocall-system.git
```

- SSHProtcolURLの登録
```
git remote add origin git@github.com:ntteast-cnw/operator-autocall-system.git
```

## 更新方法
- 変更の追加、コメント、プッシュ
```
git add -A
git commit -m "コメント"
git push origin main
```

## branchの切替
- main が今回開発のコード、beforeが現行のコード
```
git checkout "branch名"
