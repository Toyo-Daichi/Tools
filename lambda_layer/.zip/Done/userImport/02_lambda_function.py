import os
import json
import boto3
import random
import string

#
cognito = boto3.client('cognito-idp',region_name='ap-northeast-1')

def lambda_handler(event,context):
  
  # Get subscribed maillist from cognito-idp
  existUserList = getexistUserList()

  # Get maillist from clipboard json format
  clipUserSum  = len(event["list"])
  clipUserAttribute_New = [[]*i for i in range(clipUserSum)]
  clipUserAttribute_Add = [[]*i for i in range(clipUserSum)]
  cognitoUserColumn = [[]*i for i in range(10)]

  for _ in range(clipUserSum):
    # email
    cognitoUserColumn[0].append(event["list"][_][2])
    # Name
    cognitoUserColumn[1].append(event["list"][_][0])
    # employee number
    cognitoUserColumn[2].append(event["list"][_][1])
    # belongs in code
    cognitoUserColumn[3].append(event["list"][_][3])
    cognitoUserColumn[4].append(event["list"][_][4])
    cognitoUserColumn[5].append(event["list"][_][5])
    # belongs in Japanese
    cognitoUserColumn[6].append(event["list"][_][6])
    cognitoUserColumn[7].append(event["list"][_][7])
    cognitoUserColumn[8].append(event["list"][_][8])
    # request command
    _command = _Num2Command(event["list"][_][9])
    cognitoUserColumn[9].append(_command)
    
    #    
    clipUserAttribute_New[_] = [
      {'Name': 'email','Value': cognitoUserColumn[0][_]},
      {'Name': 'phone_number_verified','Value': 'false'},
      {'Name': 'email_verified','Value': 'true'}
    ]
    clipUserAttribute_Add[_] = [
      {'Name': 'custom:code', 'Value': cognitoUserColumn[1][_]},
      {'Name': 'custom:code2','Value': cognitoUserColumn[2][_]},
      {'Name': 'custom:code3','Value': cognitoUserColumn[3][_]},
      {'Name': 'custom:code4','Value': cognitoUserColumn[4][_]},
      {'Name': 'custom:code5','Value': cognitoUserColumn[5][_]},
      {'Name': 'custom:code6','Value': cognitoUserColumn[6][_]},
      {'Name': 'custom:code7','Value': cognitoUserColumn[7][_]},
      {'Name': 'custom:code8','Value': cognitoUserColumn[8][_]},
      {'Name': 'custom:code9','Value': cognitoUserColumn[9][_]}
    ]

  for _index, clipUserMail in enumerate(cognitoUserColumn[0]):
    _command = cognitoUserColumn[9][_index]
        
    if _command == 'APPEND': 
      if clipUserMail not in existUserList:
        createCognitoUser(clipUserMail,clipUserAttribute_New[_index],clipUserAttribute_Add[_index])
      else:
        updateCognitoUser(clipUserMail,clipUserAttribute_Add[_index])

    elif _command == 'DELETE':
      existUserList = deleteCognitoUser(clipUserMail)
    
    elif _command == 'MFASET':
      existUserList = deleteCognitoUser(clipUserMail)
      if clipUserMail not in existUserList:
        createCognitoUser(clipUserMail,clipUserAttribute_New[_index],clipUserAttribute_Add[_index])
      else:
        print('I recommend your set MFASET !')

    elif _command == 'MFADEL':
      existUserList = deleteCognitoUser(clipUserMail)
      if clipUserMail not in existUserList:
        createCognitoUser(clipUserMail,clipUserAttribute_New[_index],clipUserAttribute_Add[_index],password_fixed='on')
      else:
        print('I recommend your set MFADEL !')

    else:
      print('Error Occured !')
      quit()

  return {
    'statusCode': 200,
    'body': json.dumps(
        'Finish at lambda function, Good job! :)'
    )
  }

def getexistUserList():
  existUserList = []

  def getUsersWithPagenation(PaginationToken):
    response = cognito.list_users(
      UserPoolId = os.environ['USER_POOL_ID'],
      PaginationToken = PaginationToken
    )

    return response

  def workerNode(users):
    for user in users['Users']:
      existUserList.append(user)
      if 'PaginationToken' in users:
        newUsers = getUsersWithPagenation(users["PaginationToken"])
        workerNode(newUsers)

  list = cognito.list_users(
    UserPoolId = os.environ['USER_POOL_ID']
  )

  workerNode(list)

  mailList = []
  for user in existUserList:
    for node in user['Attributes']:
      if node['Name'] == 'email':
        mailList.append(node['Value'])

  return mailList

def createCognitoUser(clipUserMail,clipUserAttribute_New,clipUserAttribute_Add,*,password_fixed='off'):
  #
  print('Add subscribed email: {} '.format(clipUserMail))
  if password_fixed == 'on':
    password = os.environ['FIX_PASSWORD']
  elif password_fixed == 'off':
    password = 'Abc'.join(random.choices(string.digits,k=5))
  
  cognito.admin_create_user(
    UserPoolId = os.environ['USER_POOL_ID'],
    Username = clipUserMail,
    TemporaryPassword = password,
    UserAttributes = clipUserAttribute_New+clipUserAttribute_Add,
    MessageAction = 'SUPPRESS'
  )

  # Try -> Login and Request Password change
  response = cognito.admin_initiate_auth(
    UserPoolId = os.environ['USER_POOL_ID'],
    ClientId = os.environ['CLIENT_ID'],
    AuthFlow = 'ADMIN_NO_SRP_AUTH',
    AuthParameters = {
      'USERNAME': clipUserMail,
      'PASSWORD': password
    }
  )
  session = response['Session']
  
  # change Password
  response = cognito.admin_respond_to_auth_challenge(
    UserPoolId = os.environ['USER_POOL_ID'],
    ClientId = os.environ['CLIENT_ID'],
    ChallengeName = 'NEW_PASSWORD_REQUIRED',
    ChallengeResponses={
      'USERNAME': clipUserMail,
      'NEW_PASSWORD': password
      },
    Session=session
    )

def updateCognitoUser(clipUserMail,clipUserAttribute_Add):
  #
  print(' An account with the given {} already exists.'.format(clipUserMail))
  cognito.admin_update_user_attributes(
    UserPoolId = os.environ['USER_POOL_ID'],
    Username = clipUserMail,
    UserAttributes = clipUserAttribute_Add
  )

def deleteCognitoUser(clipUserMail):
  try:
    cognito.admin_delete_user(
      UserPoolId = os.environ['USER_POOL_ID'],
      Username   = clipUserMail
    )
    updateExistUserList = getexistUserList()
    print('Delete subscribed email: {} '.format(clipUserMail))
    return updateExistUserList

  except:
    print("I recommend your Clipboard command Column !")


def _Num2Command(x:int) -> str:
  if x == 1:
    x = 'APPEND'
  elif x ==2:
    x = 'DELETE'
  elif x ==3:
    x = 'MFASET'
  elif x ==4:
    x = 'MFADEL'
  
  return x
