list=[
['daichi.toyooka.gu@east.ntt.co.jp','000000','OTHER'],
['ryo.yoshikawa.px@east.ntt.co.jp','000000','OTHER'],
['yoshio.nakamura.nw@east.ntt.co.jp','000000','OTHER']
]