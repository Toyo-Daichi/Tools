lambdaimport os
import json
import boto3
import userList
from datetime import datetime
import uuid
import random
import string



cognito = boto3.client('cognito-idp', region_name='ap-northeast-1')

def lambda_handler(event, context):


    # Cognitoからユーザーを削除する
    existUserList=getExistUserList()
    
    for node in userList.list:

    
        init_attribute=[
            {'Name': 'email', 'Value':node[0]},            
            {"Name": "phone_number_verified","Value": "false"},
            {"Name": "email_verified","Value": "true"},   
        ]

        attribute=[

            # {"Name": "address","Value": "tokyo"},
            # {"Name": "name","Value": "yoshio nakamura"},
            # {"Name": "nickname","Value": "yoshio000"},
            {"Name": "custom:code","Value": node[1]},
            {"Name": "custom:code2","Value": node[2]},
        ]

    
        if node[0] not in existUserList:
            print(node[0])




            password='Abc'.join(random.choices(string.digits, k=5))            

            cognito.admin_create_user(
                UserPoolId=os.environ['USER_POOL_ID'],
                Username=node[0],
                TemporaryPassword=password,
                UserAttributes=init_attribute+attribute,
                MessageAction='SUPPRESS'
            )
            
            # ログインを試みる。（パスワードの変更を要求される。）
            response = cognito.admin_initiate_auth(
                UserPoolId=os.environ['USER_POOL_ID'],
                ClientId=os.environ['CLIENT_ID'],
                AuthFlow='ADMIN_NO_SRP_AUTH',
                AuthParameters={'USERNAME': node[0], 'PASSWORD': password},
            )
            session = response['Session']
            
            # パスワードを変更する。
            response = cognito.admin_respond_to_auth_challenge(
                UserPoolId=os.environ['USER_POOL_ID'],
                ClientId=os.environ['CLIENT_ID'],
                ChallengeName='NEW_PASSWORD_REQUIRED',
                ChallengeResponses={'USERNAME': node[0], 'NEW_PASSWORD': password},
                Session=session
            )         
        else:

            
            cognito.admin_update_user_attributes(
                UserPoolId=os.environ['USER_POOL_ID'],
                Username=node[0],
                UserAttributes=attribute
            )
                        
    return



def getExistUserList():   
    
    existUserList=[]
    
    def getUsersWithPagenation(PaginationToken):
        response = cognito.list_users(
            UserPoolId=os.environ['USER_POOL_ID'],
            PaginationToken=PaginationToken
        )
        return response
    
    def workerNode(users):
        for user in users["Users"]:
            existUserList.append(user)
        if 'PaginationToken' in users:
            newUsers = getUsersWithPagenation(users["PaginationToken"])
            workerNode(newUsers)    

    

    list = cognito.list_users(
        UserPoolId = os.environ['USER_POOL_ID']
    )
    workerNode(list)    
    
    mailList=[]
    for user in existUserList:
        for node in user['Attributes']:
            if node['Name'] == 'email':
                mailList.append(node['Value'])
    return mailList


