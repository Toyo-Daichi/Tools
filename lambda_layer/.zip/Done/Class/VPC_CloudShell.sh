#!/bin/bash
region_list=(
us-east-1 us-east-2 us-west-1 us-west-2
ap-south-1 ap-southeast-1 ap-southeast-2 ap-northeast-1 ap-northeast-2 ap-southeast-1
ca-central-1
eu-central-1 eu-west-1 eu-west-2 eu-west-3 eu-north-1
sa-east-1
)

for iregion in ${region_list[@]}; do
	aws service-quotas request-service-quota-increase --service-code vpc --quota-code L-F678F1CE --region ${iregion} --desired-value 100 
  echo '-----------------------------------------------------------------------------------------'
  sleep 1s
done
#
echo 'Normal END'

exit
