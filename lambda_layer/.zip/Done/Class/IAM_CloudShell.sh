#!/bin/bash
# Make, add IAM Group and User 

Group='DX_University'
User_num=20
#
aws iam create-group --group-name ${Group}

# attach-policy 
# Cloud
aws iam attach-group-policy --group-name ${Group} --policy-arn arn:aws:iam::aws:policy/AmazonEC2FullAccess
aws iam attach-group-policy --group-name ${Group} --policy-arn arn:aws:iam::aws:policy/AmazonS3FullAccess
aws iam attach-group-policy --group-name ${Group} --policy-arn arn:aws:iam::aws:policy/AWSCloudFormationFullAccess
# AI
aws iam attach-group-policy --group-name ${Group} --policy-arn arn:aws:iam::aws:policy/AmazonSageMakerFullAccess
#
aws iam attach-group-policy --group-name ${Group} --policy-arn arn:aws:iam::aws:policy/IAMUserChangePassword

for inum in `seq 1 ${User_num}`; do
  User=${Group}_`printf %2.4i ${inum}`
  aws iam create-user --user-name ${User} --tags Key='service',Value='University' Key='owner',Value='NTTeast'
  aws iam create-login-profile --user-name ${User} --password 'NttEast-12345' --password-reset-required
  aws iam add-user-to-group --user-name ${User} --group-name ${Group}
  echo '-----------------------------------------------------------------------------------------'
done
#
echo 'Normal END'

exit
