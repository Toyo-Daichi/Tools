#!/bin/bash
aws iam create-role --path /service-role/ --role-name AmazonSageMakerExecutionRole  --assume-role-policy-document file://s3.json --tags Key='service',Value='University'
aws iam attach-role-policy --role-name AmazonSageMakerExecutionRole --policy-arn arn:aws:iam::aws:policy/AmazonSageMakerFullAccess