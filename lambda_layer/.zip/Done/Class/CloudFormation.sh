#!/bin/bash
region_list=(ap-northeast-1)
#region_list=(ap-northeast-1 us-east-2 eu-west-2 sa-east-1)
#region_list=(ap-southeast-1 ap-south-1)

for iregion in ${region_list[@]}; do
  docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli \
  cloudformation create-stack --stack-name Toyooka-cfn --template-body file://Class/CloudFormation.yml --region ${iregion}
  #docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli \
  #cloudformation delete-stack --stack-name Toyooka-cfn --region ${iregion}
	#
  sleep 3s
done

exit 
