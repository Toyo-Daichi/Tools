#!/bin/bash

sudo su
yum update -y
yum install -y httpd.x86_64
systemctl start httpd.service
systemctl enable httpd.service

cat << EOF > /var/www/html/index.html
<!DOCTYPE html>
<html lang="ja">
  <head>
    <meta charset="UTF-8">
    <title>ハンズオン</title>
  </head>
  <body>
    <h1>テストページ</h1>
    
    <!--ここの部分を変更してみてください！！！-->
    <p>Amazon EC2を用いてWebサーバ構築ができました！</p>
    <!--/-->

  </body>
</html>
EOF

echo "Normal END"

exit