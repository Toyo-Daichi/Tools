#!/bin/bash
# Created on 2021.8.26
# Upload CloudShell
# or
alias aws='docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli'
aws_relative_path='Call'

#set -x

#----------------------------------------------------------------------
# +++ Set configure
#----------------------------------------------------------------------
sysname="ocs"
env="dev"
type="lambda"
use="postslack" #"mailcheck" or "connectcall" or "loopcheck" or "postslack"
#
status="create" # "create" or "update"
#
lambda_name=${sysname}-${env}-${type}-${use}
role_arn="arn:aws:iam::386884265435:role/lambda_basic_execution"

if [ ${use} = "mailcheck" -o ${use} = "loopcheck" ]; then
  environmental_var="Variables={ENV=${env}}"
elif [ ${use} = "postslack" ]; then
  slack_token="xoxb-1751570926869-2408010652962-rCFZ39bqw2guSuKOYp1quhw9"
  slack_channel="C02C5DS0K44"
  environmental_var="Variables={ENV=${env},SLACK_TOKEN=${slack_token},SLACK_CHANNEL=${slack_channel}}"
elif [ ${use} = "connectcall" ]; then
  connect_id="4a821f7c-73b2-499a-bb24-57b085eb5cc0"
  connect_flow="44eb2575-e152-4860-a3a3-4089b479b0d0"
  connect_min=30
  connect_prompt=\
  "XXXXX,ssmonitoring,omakase-cyber-cc,omakase-cyber-off,dpbx,siam_auto_operation,cloud-siam-notify-primary-measure-request"
  stepfunction_arn="examplez-0101010101"
  #
  environmental_var="Variables={ENV=${env},CONNECT_INSTANCE=${connect_id},CONNECT_FLOW=${connect_flow},CONNECT_MIN=${connect_min},CONNECT_PROMPT=${connect_prompt},STEPFUNCTION_ARN=${stepfunction_arn}}"
fi

#----------------------------------------------------------------------
# +++ lambda func. 
#----------------------------------------------------------------------
create_lambda(){
  echo 'Check Environmental var : ' $1
  sleep 3s
  #
  aws lambda create-function --function-name ${lambda_name}  \
  --zip-file fileb://${aws_relative_path}/${lambda_name}.zip \
  --handler lambda_function.lambda_handler --runtime python3.7 --role ${role_arn} \
  --environment $1
}

update_lambda(){
  echo 'Check Environmental var : ' $1
  sleep 3s
  #
  aws lambda update-function-code --function-name ${lambda_name} \
  --zip-file fileb://${aws_relative_path}/${lambda_name}.zip     \
  --environment $1 
}

#----------------------------------------------------------------------
# +++ Execution
#----------------------------------------------------------------------
cd ${HOME}/${aws_relative_path}/${lambda_name}
zip -r ${HOME}/${aws_relative_path}/${lambda_name}.zip *

if [ ${status} = "create" ]; then
  create_lambda ${environmental_var}
elif [ ${set} = "update" ]; then
  update_lambda ${environmental_var}
else
  echo 'Check your status code'
fi

rm ${HOME}/${aws_relative_path}/${lambda_name}.zip
echo 'Normal END'

exit
