#!/bin/bash
# Created on 2021.9.21
# Upload CloudShell
# or
alias aws='docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli'
aws_relative_path='Call'

#set -x

#----------------------------------------------------------------------
# +++ Set configure
#----------------------------------------------------------------------
sysname="ocs"
env="dev"
type="lambda"
use="postslack" #"mailcheck" or "connectcall" or "loopcheck" or "postslack"
#
lambda_name=${sysname}-${env}-${type}-${use}
lambda_layer=${sysname}-${env}-${type}-layer-${use}
#
layer_file="${HOME}/Tools/lambda_layer"

#----------------------------------------------------------------------
# +++ lambda func. 
#----------------------------------------------------------------------
upload_lambda_layer(){
  aws lambda publish-layer-version --layer-name ${lambda_layer}
}

#----------------------------------------------------------------------
# +++ Execution
#----------------------------------------------------------------------
zip -r ${HOME}/${aws_relative_path}/${lambda_name}.zip *


rm ${HOME}/${aws_relative_path}/${lambda_name}.zip
echo 'Normal END'

exit
