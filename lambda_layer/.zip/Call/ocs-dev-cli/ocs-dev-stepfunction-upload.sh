#!/bin/bash
# Created on 2021.9.14
# Upload CloudShell
# or
alias aws='docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli'
aws_relative_path='Call'

#set -x

#----------------------------------------------------------------------
# +++ Set configure
#----------------------------------------------------------------------
sysname="ocs"
env="dev"
type="stepfunction"
use="callstatus"
#
stepfunction_name=${sysname}-${env}-${type}-${use}

# status
call_sum=15
wait_sec=120; call_again_sec=120

# arn
role_arn="arn:aws:iam::386884265435:role/ocs-iam-role-stepfunction"
#
lambda_connectcall_arn="arn:aws:lambda:ap-northeast-1:386884265435:function:ocs-dev-lambda-connectcall"
lambda_loopcheck_arn="arn:aws:lambda:ap-northeast-1:386884265435:function:ocs-dev-lambda-loopcheck"
lambda_postslack_arn="arn:aws:lambda:ap-northeast-1:386884265435:function:ocs-dev-lambda-postslack"

# Stepfunction (Amazon States Laguage)
cat << EOF > ./test/asl.json
{
  "Comment": "${stepfunction_name}", 
  "StartAt": "ConfigureLoopParams",
  "States": {
    "ConfigureLoopParams": {
      "Comment": "発信用Lambdaからインプットを受け取りループパラメータを設定する",
      "Type": "Pass",
      "InputPath": "$",
      "ResultPath": "$.loop_params",
      "Next": "WaitUntilCheck"
    },
    "WaitUntilCheck": {
      "Comment": "待機する(180s: 呼び出しのタイムアウト時間+1分)",
      "Type": "Wait",
      "Seconds": ${wait_sec},
      "Next": "CheckCallStatus"
    },
    "CheckCallStatus": {
      "Comment": "発信ステータス(相手が電話に出たかどうか)を取得するLambdaを起動する",
      "Type": "Task",
      "Resource": "${lambda_loopcheck_arn}",
      "InputPath": "$.loop_params",
      "ResultPath": "$.loop_params",
      "Next": "ChoiceLoopStatus"
    },
    "ChoiceLoopStatus": {
      "Comment": "発信ステータスが未応答且つ発信回数が3回以下の場合再発進処理へ、それ以外は処理終了。",
      "Type": "Choice",
      "Choices": [
        {
          "And": [
            {
              "Variable": "$.loop_params.call_status",
              "StringEquals": "unanswered"
            },
            {
              "Variable": "$.loop_params.call_times",
              "NumericLessThanEquals": ${call_sum}
            }
          ],
          "Next": "WaitUntilCallAgain"
        }
      ],
      "Default": "PostSlack"
    },
    "WaitUntilCallAgain": {
      "Comment": "再発進するまで待機する(${call_again_sec} sec : 3-5min)",
      "Type": "Wait",
      "Seconds": ${call_again_sec},
      "Next": "CallAgain"
    },
    "CallAgain": {
      "Comment": "再発進する",
      "Type": "Task",
      "Resource": "${lambda_connectcall_arn}",
      "InputPath": "$.loop_params",
      "ResultPath": "$.loop_params",
      "Next": "WaitUntilCheck"
    },
    "PostSlack": {
      "Comment": "Slackに投稿する",
      "Type": "Task",
      "Resource": "${lambda_postslack_arn}",
      "InputPath": "$.loop_params",
      "Next": "ExitLoop"
    },
    "ExitLoop": {
      "Comment": "ループを抜けて処理を終了する",
      "Type": "Succeed"
    }
  }
}
EOF

#----------------------------------------------------------------------
# +++ stepfunction func. 
#----------------------------------------------------------------------
create_state_machine(){
  aws stepfunctions create-state-machine --name ${stepfunction_name} \
  --definition file://${aws_relative_path}/${sysname}-${env}-cli/test/asl.json \
  --role-arn "${role_arn}" \
  --tags key='Name',value=${stepfunction_name} key='owner',value='Toyooka' \
         key='enviroment',value=${env} key='sysname',value=${sysname}

  sleep 3s
}

#----------------------------------------------------------------------
# +++ Execution
#----------------------------------------------------------------------
create_state_machine

rm ./test/asl.json
echo 'Normal END'

exit
