import os
import logging
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError

# config
client = WebClient(token=os.environ['SLACK_TOKEN'])
logger = logging.getLogger(__name__)
channel_id = os.environ['SLACK_CHANNEL']

def lambda_handler(event, context):
  """slackへ投稿
    Args:
      example event = {
        "loop_status": "true",
        "srvname": "field-assistant",
        "altType": "zabbix",
        "alertTypePronunciation": "ザビックスアラート",
        "alert_time_item": "recent_zbx_alert_time",
        "contact_id": "628f1984-1551-4612-b31a-6330bb63f8cd",
        "call_times": 3,
        "call_status": "answered"
      }
     
    Notes:
      使用するargsは, { "alertTypePronunciation" : xxx}
      Lambda側でslack_sdkのレイヤーを追加する必要あり
   """
  try:
    if event['call_status'] == 'unanswered':
      msg = '{}アラートです。担当者が手配されていません。'.format(event["service"])
      submit = "<!here>\n" + msg
    else:
      msg = '{}アラートです。担当者が手配されました'.format(event['service'])
      submit = msg
        
    result = client.chat_postMessage(
        channel=channel_id,
        text= submit,
    )
    logger.info(result)
  
  except SlackApiError as e:
      logger.error(f"Error posting message: {e}")