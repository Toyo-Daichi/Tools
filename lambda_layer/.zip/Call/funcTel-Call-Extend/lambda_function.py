# -*- coding: utf-8 -*-
##############################################################
# [Lambda関数名]
# funcTel-Call-Extended
# [説明]
# サービス名、イベント種別を判別し、Amazon Connectに発信リクエストを発行する
##############################################################
#################################
# ライブラリ、モジュールインポート #
#################################
import json
import boto3
import re
import os
import configparser
import random
import time
from datetime import datetime
from boto3.dynamodb.conditions import Key, Attr

###########
# 定数定義 #
###########
# Amazon Connect定義
# INIファイル読み込み
connect_ini = configparser.SafeConfigParser()
connect_ini.read('./connect.ini')
# リージョン取得
region= connect_ini.get('connect', 'region')
# インスタンスID取得
instanceId = connect_ini.get('connect', 'InstanceId')
# コンタクトフローID取得
contactFlowId = connect_ini.get('connect', 'ContactFlowId')

connect = boto3.client('connect', region_name=region)

# DynamoDB定義
dynamodb = boto3.resource('dynamodb')
table_name = 'connect_conf'
dynamotable = dynamodb.Table(table_name)

# チャタリング抑止用時刻差分の閾値、及びカスタムプロンプト利用定義
# INIファイル読み込み
env_ini = configparser.SafeConfigParser()
env_ini.read('./env.ini')
# 時刻差分の閾値(分)を取得
TimeDifference = env_ini.get('env', 'TimeDifference')
# 閾値を秒に変換
TimeDifference_Sec = float(TimeDifference) * 60
# カスタムプロンプト利用定義を取得
useCustomPrompt = env_ini.get('env', 'useCustomPrompt')

# S3定義
s3 = boto3.resource('s3')
s3UrlParent = 'https://s3.us-east-1.amazonaws.com/'
bucketName = 'configuration-for-connect'
promptDir = 'Prompt/'
prompPrefix = 'Prompt-'
prompSuffix = '.txt'
basePromptFile = promptDir + prompPrefix + 'base' + prompSuffix

# Step Functions定義
stepfunctions = boto3.client('stepfunctions')
# INIファイル読み込み
stepfunctions_ini = configparser.SafeConfigParser()
stepfunctions_ini.read('./stepfunctions.ini')
# ステートマシンARN取得
stateMachineArn = stepfunctions_ini.get('stepfunctions', 'stateMachineArn')

###########
# 関数定義 #
###########
# ランダムsleep関数
def random_sleep():
    # 1～5秒の間でランダムなsleep時間(float型)を取得
    sleep_time = random.uniform(1,5)
    # ログ出力
    print('[Debug：ランダム待機]' + str(sleep_time) + '秒待機します')
    # 取得した時間分sleep
    time.sleep(sleep_time)

# ファイル存在確認関数
def file_existence_check(file):
    try:
        s3.ObjectSummary(bucket_name=bucketName, key=file).load()
    except Exception as e:
        return False
    return True

# プロンプト生成関数
def generate_Prompt(promptFile, PromptType, srvNamePronunciation, alertTypePronunciation):
    # プロンプトタイプ判定
    if PromptType == 'custom':
        # プロンプトタイプがカスタムの場合
        # S3からプロンプトファイルを読み込み
        resPrompt = s3.Object(bucketName, promptFile)
        rawMessage = resPrompt.get()['Body'].read().decode('utf-8')
        # 読み込んだ内容をそのまま使用する
        message = rawMessage
    elif PromptType == 'base':
        # プロンプトタイプがベースの場合
        # ローカルからプロンプトファイルを読み込み
        with open('./Prompt-base.txt') as f:
            rawMessage = f.read()
        # サービス名とアラート種別を置換する
        message = rawMessage.replace('SERVICE-NAME', srvNamePronunciation).replace('ALERT-TYPE', alertTypePronunciation)

    # ログ出力
    print('[Debug：プロンプト]')
    print(message)

    return message

# 発信設定関数
def setting_call(srvname, altType, alertTypePronunciation):
    # DynamoDBテーブルから設定情報取得
    # プライマリキー定義
    primary_key = {"name": srvname}
    response = dynamotable.get_item(Key=primary_key)
    # 発信番号取得
    fromNum = response["Item"]['from-num']
    # 着信番号取得
    toNum = response["Item"]['to-num']
    # サービス名(読み)取得
    srvNamePronunciation = response["Item"]['pronunciation']

    # ログ出力
    print('[Debug：発信番号]' + fromNum)
    print('[Debug：着信番号]' + toNum)
    print('[Debug：サービス名(読み)]' + srvNamePronunciation)

    # カスタムプロンプト利用有無検索用にサービス名に終端記号としてカンマを付与
    searchSrv =  ',' + srvname + ','
    # カスタムプロンプト使用有無確認
    if searchSrv in useCustomPrompt:
        # カスタムプロンプトを利用する場合はファイルパスを生成
        customPromptFile = promptDir + prompPrefix + srvname + '_' + altType + '_custom' + prompSuffix
        # カスタムプロンプトファイルの存在確認
        if file_existence_check(customPromptFile):
            # カスタムプロンプトファイルが存在した場合のみ使用する
            # ログ出力
            print('カスタムプロンプトを使用します')
            # プロンプトタイプを'custom'に定義
            PromptType = 'custom'
            # プロンプト生成
            message = generate_Prompt(customPromptFile, PromptType, srvNamePronunciation, alertTypePronunciation)
        else:
            # カスタムプロンプトファイルが存在しない場合はテンプレートを使用する
            # ログ出力
            print('カスタムプロンプトが見つからかった為、テンプレートを使用します')
            # S3からファイルを読み込み
            # プロンプトタイプを'base'に定義
            PromptType = 'base'
            # プロンプト生成
            message = generate_Prompt(basePromptFile, PromptType, srvNamePronunciation, alertTypePronunciation)
    else:
        # テンプレートのプロンプトを使用する
        # プロンプトタイプを'base'に定義
        PromptType = 'base'
        # プロンプト生成
        message = generate_Prompt(basePromptFile, PromptType, srvNamePronunciation, alertTypePronunciation)

    return fromNum, toNum, message

# Connect連携関数
def connect_call(fromNum, toNum, message):
    # ログ出力
    print('[Debug：発信開始]')

    # Connect呼び出し
    response = connect.start_outbound_voice_contact(
        DestinationPhoneNumber=toNum,
        ContactFlowId=contactFlowId,
        InstanceId=instanceId,
        SourcePhoneNumber=fromNum,
        Attributes={
            'message': message,
            'call_status': 'unanswered'
        }
    )

    # コンタクトIDを取得
    contact_id = response['ContactId']
    # ログ出力
    print('[Debug：コンタクトID]' + contact_id)    
    # コンタクトIDを返却
    return contact_id

# 発信ステータス取得関数
def get_attributes(contact_id):
    response = connect.get_contact_attributes(
        InstanceId=instanceId,
        InitialContactId=contact_id
    )
    call_status = response['Attributes']['call_status']
    return call_status

# アラート受信時刻更新関数
def update_alert_time(srvname, alert_time_item):
    # 現在の時刻(unix時間)を取得
    now = datetime.now()
    now_ts = now.timestamp()
    # ログ出力
    print('アラート受信時刻を更新します')                

    # DynamoDBテーブル更新用属性名定義
    primary_key = {"name": srvname}
    UpdateExpStr = 'set '+alert_time_item+' = :'+alert_time_item
    ExprAttrStr = ':'+alert_time_item

    # DynamoDBテーブル内の時刻を更新
    response = dynamotable.update_item(
        Key=primary_key,
        UpdateExpression=UpdateExpStr,
        ExpressionAttributeValues={
            ExprAttrStr: str(now_ts)
        }
    )

# ループ用ステートマシン起動関数
def start_loop(srvname, altType, alertTypePronunciation, alert_time_item, contact_id, call_status):
    response = stepfunctions.start_execution(
        **{
            'input' : "{\
                \"loop_status\": \"true\", \
                \"srvname\": \"" + srvname + "\", \
                \"altType\": \"" + altType + "\", \
                \"alertTypePronunciation\": \"" + alertTypePronunciation + "\", \
                \"alert_time_item\": \"" + alert_time_item + "\", \
                \"contact_id\": \"" + contact_id + "\", \
                \"call_times\": 1, \
                \"call_status\": \"" + call_status + "\" \
            }",
            'stateMachineArn' : stateMachineArn
        }
    )

# メイン関数
def lambda_handler(event, context):
    # 初回発信か、2回目以降の発信かを、イベントオブジェクトの特定キーの有無で判定
    if not 'loop_status' in event:
        # イベントオブジェクトからアラート種別を取得
        altType_obj = event['AlertType'] 
        altType = str(altType_obj)
        # イベントオブジェクトからアラート種別(読み)を取得
        alertTypePronunciation_obj = event['AlertTypePronunciation']            
        alertTypePronunciation = str(alertTypePronunciation_obj)
        # イベントオブジェクトからサービス名を取得
        srvname_obj = event['srv_name']
        srvname = str(srvname_obj)
    
        # ログ出力
        print('[Debug：イベント種別]' + altType)
        print('[Debug：イベント種別(読み)]' + alertTypePronunciation)
        print('[Debug：サービス名]' + srvname)

        # アラート種別からDynamoDBの直近アラート時間アイテム名を定義
        if altType == 'zabbix':
            alert_time_item = 'recent_zbx_alert_time'
        elif altType == 'cloudwatch':
            alert_time_item = 'recent_cldw_alert_time'
        elif altType == 'health':
            alert_time_item = 'recent_health_alert_time'
        elif altType == 'deepsecurity':
            alert_time_item = 'recent_ds_alert_time'         
        
        # 1～5秒の間でランダムに待機する
        random_sleep()

        # プライマリキー定義
        primary_key = {"name": srvname}
        # DynamoDBテーブルから直近のアラート受信時刻を取得
        response = dynamotable.get_item(Key=primary_key, ConsistentRead=True)
        recentAlertTimeStr = response["Item"][alert_time_item]
        recentAlertTime = float(recentAlertTimeStr)

        # 現在の時刻(unix時間)を取得
        now = datetime.now()
        now_ts = now.timestamp()
        # 現在日時と直近でアラート受信した日時との差(秒)を算出
        diff = float(now_ts) - recentAlertTime
        # ログ出力
        print('[Debug：時刻差分(秒)]' + str(diff))

        if diff <= TimeDifference_Sec:
            # 時刻差が閾値以下である場合は、DynamoDBテーブル内の時刻を更新し、処理を中断
            update_alert_time(srvname, alert_time_item)
            # ログ出力
            print('直近のアラート受領時刻からの経過時間が' + TimeDifference + '分以下の為、処理を中断します')
        else:
            # 時刻差が閾値より大きい場合は、電話番号とプロンプトを取得
            result = setting_call(srvname, altType, alertTypePronunciation)
            # Connect連携関数を呼び出し、コンタクトIDを取得する
            contact_id = connect_call(result[0], result[1], result[2])
            # DynamoDBテーブル内の時刻を更新
            update_alert_time(srvname, alert_time_item)
            # コンタクトIDの属性から発信ステータスを取得
            call_status = get_attributes(contact_id)
            # ログ出力
            print('[CallLog]サービス名：'+srvname+', アラート種別：'+altType+', コンタクトID：'+contact_id+', 発信回数：1回目, 発信ステータス：'+call_status)

            # ループ開始               
            start_loop(srvname, altType, alertTypePronunciation, alert_time_item, contact_id, call_status)
    else:
        print(event)
        # 発信設定関数を呼び出し、電話番号とプロンプト情報を取得
        result = setting_call(event['srvname'], event['altType'], event['alertTypePronunciation'])
        # Connect連携関数を呼び出し、コンタクトIDを取得
        contact_id = connect_call(result[0], result[1], result[2])        
        # DynamoDBテーブル内の時刻を更新
        update_alert_time(event['srvname'], event['alert_time_item'])
        # コンタクトIDの属性から発信ステータスを取得
        call_status = get_attributes(contact_id)
        # ログ出力
        print('[CallLog]サービス名：'+event['srvname']+', アラート種別：'+event['altType']+', コンタクトID：'+contact_id+', 発信回数：'+str(event['call_times'])+'回目, 発信ステータス：'+call_status)

        # loopパラメータ生成
        response = {
            "loop_status": event['loop_status'],
            "srvname": event['srvname'],
            "altType": event['altType'],
            "alertTypePronunciation": event['alertTypePronunciation'],
            "alert_time_item": event['alert_time_item'],            
            "contact_id": contact_id,
            "call_times": event['call_times'],
            "call_status": call_status
        }
        # ステートマシンにloopステータスを返却
        return response