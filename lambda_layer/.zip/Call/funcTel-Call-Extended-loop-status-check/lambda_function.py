# -*- coding: utf-8 -*-
##############################################################
# [Lambda関数名]
# funcTel-Call-Extended-loop-status-check
# [説明]
# connectの発信ステータス(相手が電話に出たかどうか)をチェックし、
# ループ継続or終了の判定を行う為のパラメータ生成を
##############################################################
#################################
# ライブラリ、モジュールインポート #
#################################
import boto3
import configparser

# Amazon Connect定義
# INIファイル読み込み
connect_ini = configparser.SafeConfigParser()
connect_ini.read('./connect.ini')
# リージョン取得
region= connect_ini.get('connect', 'region')
# インスタンスID取得
instanceId = connect_ini.get('connect', 'InstanceId')

connect = boto3.client('connect', region_name=region)

# 発信ステータス取得関数
def get_attributes(contact_id):
    response = connect.get_contact_attributes(
        InstanceId=instanceId,
        InitialContactId=contact_id
    )
    call_status = response['Attributes']['call_status']
    return(call_status)

# メイン関数
def lambda_handler(event, context):
    # 発信ステータス取得
    call_status = get_attributes(event['contact_id'])
    # インベントオブジェクトから現在までの発信回数を取得
    previouscall_times = event['call_times']
    # 発信回数をカウントアップ
    call_times = int(previouscall_times) + 1

    # ログ出力
    print('[CallLog]サービス名：'+event['srvname']+', アラート種別：'+event['altType']+', コンタクトID：'+event['contact_id']+', 発信回数：'+str(previouscall_times)+'回目, 発信ステータス：'+call_status)

    # loopパラメータ生成
    response = {
        "loop_status": event['loop_status'],
        "srvname": event['srvname'],
        "altType": event['altType'],
        "alertTypePronunciation": event['alertTypePronunciation'],
        "alert_time_item": event['alert_time_item'],    
        "contact_id": event['contact_id'],
        "call_times": call_times,
        "call_status": call_status
    }
    # ステートマシンにloopパラメータを返却
    return response
