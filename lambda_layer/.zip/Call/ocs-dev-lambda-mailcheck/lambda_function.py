# -*- coding: utf-8 -*-
"""
[Lambda関数名]
ocs-dev-lambda-mailcheck
[説明]
S3イベントから起動し、送信元アドレス/件名からメールの振分けを行う
[変更履歴]
2019/XX CNW ... funcTel-MailSort-Extended
2021/08 CNW ... ocs-env-lambda-mailcheck
"""

import os
#
import boto3
from boto3.dynamodb.conditions import Key, Attr
import email
from email.header import decode_header
from email.utils import getaddresses
import json
import re
import urllib.parse

"""AWS Service"""
s3 = boto3.resource('s3')
dynamodb = boto3.resource('dynamodb')
clientLambda = boto3.client('lambda')
#
funcName='ocs-{}-lambda-connectcall'.format(os.environ['ENV'])

"""DyanamoDB Table"""
# 電話番号設等定用テーブル
conf_tbl_name = 'ocs-{}-dynamo-configuration'.format(os.environ['ENV'])
conf_dynamotable = dynamodb.Table(conf_tbl_name)
# 抑止設定用テーブル
valve_tbl_name = 'ocs-{}-dynamo-valve'.format(os.environ['ENV'])
valve_dynamotable = dynamodb.Table(valve_tbl_name)
# メール本文検索キーワード用テーブル
keyword_tbl_name = 'ocs-{}-dynamo-bodykeyword'.format(os.environ['ENV'])
keyword_dynamotable = dynamodb.Table(keyword_tbl_name)

"""Email categorization"""
# SNS送信元メールアドレス
sns_mladdr = r'no-reply@sns.amazonaws.com'
# CloudWatchアラームメール件名検索文字列
chk_alarm = 'ALARM:'
chk_rds = 'RDS'
# Zzbbix(3EaaS含む)アラートメール件名検索文字列
chk_zabbix = r'PROBLEM'
chk_zabbix_3eaas = r'3EaaS'
# DeepSecurityアラート本文検索文字列
chk_deep = r'Deep Security'
# ダイヤPBX向け件名検索文字列
chk_crit = r'critical'
chk_warn = r'warning'
# ヘルスイベント(issue)検索文字列
chk_issue = r'"eventtypecategory":"issue"'

"""Function"""
def get_email_info(event):
  """受信メール情報取得
  Args:
    event(json): s3 trigger information 
      *https://docs.aws.amazon.com/ja_jp/lambda/latest/dg/with-s3.html
  
  Returns:
    key(str)          : s3 object key
    from_mladdr(str)  : From mail address
    to_mladdr(str)    : To mail address
    ml_subject(str)   : mail subject
    decoded_body(str) : mail contents decoded on 'utf-8'
    raw_body(str)     : mail original contents
    srvname(str)      : service cats3_trigger.jsonegory

  Notes:
    s3 trigger information json format
      - https://docs.aws.amazon.com/ja_jp/lambda/latest/dg/with-s3.html
      - ./json/s3_trigger.json
  """
  
  # メール保存先S3バケット名取得
  bucket = event['Records'][0]['s3']['bucket']['name']
  # オブジェクトキー取得
  key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'])
  # オブジェクト取得
  s3_object = s3.Object(bucket, key)
  # オブジェクトの中身を取得
  s3_object_response = s3_object.get()
  email_body = s3_object_response['Body'].read().decode('utf-8')
  email_object = email.message_from_string(email_body)

  # 送信元メールアドレス取得
  from_response = getaddresses(email_object.get_all('from', []))
  from_mladdr = from_response[0][1]

  # 送信先メールアドレス取得
  (to_addr, to_charaset) = decode_header(email_object['To'])[0]
  if to_charaset == None:
    to_mladdr = to_addr
  else:
    to_mladdr = to_addr.decode(to_charaset)

  # メール件名取得
  (subject, subject_charaset) = decode_header(email_object['Subject'])[0]
  if subject_charaset == None:
    ml_subject = subject
  else:
    ml_subject = subject.decode(subject_charaset)

  # メール本文取得
  for part in email_object.walk():
    if part.get_content_maintype() == 'multipart':
      continue
    else:
      body_charset = part.get_content_charset()
      filename = part.get_filename()
      if not filename:
        if not body_charset is None:
          decoded_body = part.get_payload(decode=True).decode(body_charset)
          raw_body = part.get_payload(decode=False)
        break

  # 送信先メールアドレスからサービス名を取得
  to_mladdr_edit = re.search("[\-_0-9a-z]+@biz-cloud[\-0-9a-z]*.awsapps.com" , to_mladdr)
  srvname_arry = to_mladdr_edit.group().split('@')
  srvname = srvname_arry[0]

  return key, from_mladdr, to_mladdr, ml_subject, decoded_body, raw_body, srvname


def judge_alert_type(from_mladdr, ml_subject, decoded_body, raw_body, srvname):
  """アラート種別判断関数
    Args:
      from_mladdr(str)  : From mail address
      ml_subject(str)   : mail subject
      decoded_body(str) : mail contents decoded on 'utf-8'
      raw_body(str)     : mail original contents
      srvname(str)      : service category
    
    Returns:
      altType(str)              : 'safe' or 'service_name'
      altTypePronunciation(str) : 'セーフ' or 'サービス名のアラート'
  """
  # 送信元がSNSであるか判定
  if re.search(sns_mladdr, from_mladdr):
    # 件名に'3EaaS' が含まれるか判定
    if (chk_zabbix_3eaas in ml_subject):
      # Zabbix(3EaaS)アラートメール処理
      # アラートタイプと読みを設定
      altType = 'zabbix'
      altTypePronunciation = 'ザビックスアラート'
      # ログ出力
      print('ザビックスアラートメール受信')
    # 件名に'ALARM:'or'RDS' が含まれるか判定
    elif (chk_alarm in ml_subject) or (chk_rds in ml_subject) or (chk_crit in ml_subject.lower()):
      # ダイヤPBX向け処理
      if (srvname == 'dpbx') and (chk_warn in ml_subject.lower()):
        # サービスがダイヤPBXの場合、Warningは鳴動対象外とする
        # アラートタイプと読みを設定
        altType = 'safe'
        altTypePronunciation = 'セーフ'
      else:
        # CloudWatchアラームメール処理
        # アラートタイプと読みを設定
        altType = 'cloudwatch'
        altTypePronunciation = 'クラウドウォッチアラーム'
        # ログ出力
        print('クラウドウォッチアラームメール受信')
    elif re.search(chk_issue, decoded_body.lower()) or re.search(chk_issue, raw_body.lower()):
      # ヘルスイベントメール処理
      # アラートタイプと読みを設定
      altType = 'health'
      altTypePronunciation = 'ヘルスイベント'
      # ログ出力
      print('ヘルスイベントメール受信')
    # 件名に'PROBLEM'が含まれるか判定
    elif re.search(chk_zabbix, ml_subject):
      # Zabbixアラートメール処理
      # アラートタイプと読みを設定
      altType = 'zabbix'
      altTypePronunciation = 'ザビックスアラート'
      # ログ出力
      print('Zabbixアラートメール受信')
    # いずれのパターンにもマッチしない場合
    else:
      # アラートタイプと読みを設定
      altType = 'safe'
      altTypePronunciation = 'セーフ'

  # 件名に'PROBLEM'が含まれるか判定
  elif re.search(chk_zabbix, ml_subject):
    # Zabbixアラートメール処理
    # アラートタイプと読みを設定
    altType = 'zabbix'
    altTypePronunciation = 'ザビックスアラート'
    # ログ出力
    print('Zabbixアラートメール受信')
  # 本文に'Deep Security'が含まれるか判定
  elif re.search(chk_deep, decoded_body):
    # Deep Securityアラートメール処理
    # アラートタイプと読みを設定
    altType = 'deepsecurity'
    altTypePronunciation = 'セキュリティーアラート'
    # ログ出力
    print('セキュリティーアラートメール受信')
  elif re.search(chk_deep, raw_body):
    # Deep Securityアラートメール処理
    # アラートタイプと読みを設定
    altType = 'deepsecurity'
    altTypePronunciation = 'セキュリティーアラート'
    # ログ出力
    print('セキュリティーアラートメール受信')
  # いずれのパターンにもマッチしない場合
  else:
    # アラートタイプと読みを設定
    altType = 'safe'
    altTypePronunciation = 'セーフ'

  return altType, altTypePronunciation

def check_srv_exists(srvname):
  """サービスのDynamoDB登録状態確認関数
    Args:
      srvname(str) : service category
    
    Returns:
      result(str) : 'OK' or 'NG'

    Notes:
      Return of dynamo query json format
      * ./dynamo_query.json
  """
  # 電話番号等設定用テーブル
  conf_response = conf_dynamotable.query(
    KeyConditionExpression=Key('name').eq(srvname)
  )
  if conf_response['Count'] == 0:
    result = 'NG'
    return result
  # 抑止設定用テーブル
  valve_response = valve_dynamotable.query(
  KeyConditionExpression=Key('name').eq(srvname)
  )
  if valve_response['Count'] == 0:
    result = 'NG'
    return result
  # 電話番号等設定用テーブル
  keyword_response = keyword_dynamotable.query(
  KeyConditionExpression=Key('name').eq(srvname)
  )
  if keyword_response['Count'] == 0:
    result = 'NG'
    return result

  result = 'OK'
  return result

def check_valve_status(srvname, altType):
  """電話鳴動開放状態取得関数
    Args:
      srvname(str) : service category
      altType(str) : 'safe' or 'service_name'
    
    Returns:
      valve_status(str) : 'open' or 'close'

    Notes:
      使用テーブルは, valve_tbl_name, valve_dynamotable = dynamodb.Table(valve_tbl_name)
  """
  # DynamoDBテーブルから設定情報取得
  primary_key = {"name": srvname}
  response = valve_dynamotable.get_item(Key=primary_key)
  # 開放状態取得
  valve_status = response["Item"][altType]
  # ログ出力
  print('[Debug：電話鳴動開放状態]' + valve_status)

  return valve_status

def get_body_keyword(srvname, altType):
  """電話鳴動開放状態取得関数
    Args:
      srvname(str) : service category
      altType(str) : 'safe' or 'service_name'
    
    Returns:
      target_line(str) : '-' or example) 深刻度:
      words(str)       : '-' or          重度

    Notes:
      使用テーブルは, keyword_tbl_name, keyword_dynamotable = dynamodb.Table(keyword_tbl_name)
      元のメッセージが"深刻度: |重度"で, | で分けている
  """
  # DynamoDBテーブルから設定情報取得
  primary_key = {"name": srvname}
  response = keyword_dynamotable.get_item(Key=primary_key)
  # キーワード取得
  response = response["Item"][altType]
  if response == '-':
    # 値が'-'の場合本文検索対象外
    # ダミーの値を設定
    target_line = '-'
    words = '-'
  else:
    # 取得した値を|(パイプ)で分割
    keyword_arry =  response.split('|')
    # 検索フォーマット
    target_line = keyword_arry[0]
    # 検索文字列
    words = keyword_arry[1]

  return target_line, words

def search_body(target_line, words, decoded_body, raw_body):
  """本文検索関数
    Args:
      target_line(str)  : '-' or example) 深刻度:
      words(str)        : '-' or          重度
      decoded_body(str) : mail contents decoded on 'utf-8'
      raw_body(str)     : mail original contents
    
    Returns:
      word(str) : '-' or example) 重度

  """
  # 検索フォーマット設定
  line_regax = target_line + ".*"
  # デコード済み本文を検索
  # フォーマットにマッチする行を検索
  line_search = re.search(line_regax , decoded_body)
  if not line_search is None:
    # マッチした部分のみ抽出
    matched_line = line_search.group()
    # 抽出した箇所に検索文字列のどれかが含まれるか検索
    for word in words.split(';'):
      if re.search(word, matched_line):
        print('[Debug：本文検索]”' + target_line + ' , ' + word +'”が検出されました')
        return word
  else:
    # デーコード済み本文にマッチする文字列がない場合は、未デコード本文を検索
    line_search = re.search(line_regax , raw_body)
    if not line_search is None:
      # マッチした部分のみ抽出
      matched_line = line_search.group()
      # 抽出した箇所に検索文字列のどれかが含まれるか検索
      for word in words.split(';'):
        if re.search(word, matched_line):
          print('[Debug：本文検索]”' + target_line + ' , ' + word +'”が検出されました')
          return word
  # 検索にマッチしなかった場合
  # ログ出力
  print('[Debug：本文検索]キーワードにマッチする文字列は検出されませんでした')
  # ダミーの値を設定
  word = '-'

  return word

def launch_call_lambda(srvname, altType, altTypePronunciation):
  """Connect連携Lambda起動関数
   Args:
      srvname(str) : service category
      altType(str) : 'safe' or 'service_name'
      altTypePronunciation(str) : 'セーフ' or 'サービス名のアラート'
  
    Returns:
      None

    Notes:
      ocs-dev-lambda-connectcallの実行
  """
  print('Connect連携Lambdaを起動')
 
  params = {
    "AlertType": altType,
    "AlertTypePronunciation": altTypePronunciation,
    "srv_name": srvname
  }
  
  print(json.dumps(params))
  res = clientLambda.invoke(
    FunctionName=funcName,
    InvocationType="Event",
    Payload=json.dumps(params)
  )

def lambda_handler(event, context):
  """
    Args:
      event(json) : s3 trigger information 
       *https://docs.aws.amazon.com/ja_jp/lambda/latest/dg/with-s3.html

    Notes:
      Connect連携Lambda 'ocs-dev-lambda-connectcall'起動で終了
  """
  # 受信メール情報取得
  response = get_email_info(event)

  # S3オブジェクトキー
  key = response[0]
  # 送信元メールアドレス
  from_mladdr = response[1]
  # 送信先メールアドレス
  to_mladdr = response[2]
  # メール件名
  ml_subject = response[3]
  # メール本文(デコード済み)
  decoded_body = response[4]
  # メール本文(未デコード)
  raw_body = response[5]
  # サービス名
  srvname = response[6]

  # ログ出力
  print('[Debug：S3オブジェクトキー]' + key)
  print('[Debug：fromアドレス]' + from_mladdr)
  print('[Debug：toアドレス]' + to_mladdr)
  print('[Debug：件名]' + ml_subject)
  print('[Debug：サービス名]' + srvname)

  # アラート種別判定
  type_response = judge_alert_type(from_mladdr, ml_subject, decoded_body, raw_body, srvname)
  # アラート種別
  altType = type_response[0]
  # アラート種別(読み)
  altTypePronunciation = type_response[1]

  if altType == 'safe':
    # 通知対象外メールの為、処理終了
    # ログ出力
    print('通知対象外メールの為、処理終了')
    # 処理終了
  else:
    # サービスのDynamoDB登録状態確認
    res_exist = check_srv_exists(srvname)
    if not res_exist == 'OK':
      print('サービス名' + srvname + 'は、DynamoDBに登録されていません。処理を中断します。')
    else:
      # 電話鳴動開放状態確認
      valve_stattus = check_valve_status(srvname, altType)
      if valve_stattus == 'close':
        # 状態が'close'(閉塞)である場合は、アラート抑止中の為処理終了
        # ログ出力
        print('アラート抑止中の為、処理を終了します')
      else:
        # 本文検索キーワード取得
        keyword_response = get_body_keyword(srvname, altType)
        # 検索フォーマット
        target_line = keyword_response[0]
        # 検索文字列
        words = keyword_response[1]

        if target_line == '-':
          # 検索フォーマットが'-'の場合は、本文検索不要
          # ログ出力
          print('キーワード指定がない為、本文検索をスキップします')

          # Connect連携Lambda関数呼び出し
          launch_call_lambda(srvname, altType, altTypePronunciation)
        else:
          # 取得したフォーマット、文字列で本文を検索
          search_body_response = search_body(target_line, words, decoded_body, raw_body)
          # 検索にヒットした場合、Connect連携Lambda関数呼び出し
          if not search_body_response == '-':
            launch_call_lambda(srvname, altType, altTypePronunciation)
          else:
            # 検索にヒットしなかった場合、通知対象外メールの為、処理終了
            # ログ出力
            print('通知対象外メールの為、処理終了')

  print('Normal END')