# 担当者呼び出しシステム

## 作成日
2021.08

## タグルール
- environment：dev
- sysname：ocs
- owner：作成者のIAM
- Name：命名規則に従う

## 命名規則
基本的には以下で設定  
{sysname}-{env}-{type}-{use}

- 対象システムの名前(sysname)：システムで一意となる識別子(例：xxsystem)
- 環境(env)：本番、検証、開発など(prod/stg/dev)
- 種別(type)：アプリケーションサーバー、踏み台サーバー、メールサーバーなど(app/bastion/mail)
- 目的(use)：ログ保管用、静的コンテンツ配信用など(log/contents)
