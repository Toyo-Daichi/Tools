# -*- coding: utf-8 -*-
"""
[Lambda関数名]
ocs-dev-lambda-loopcheck
[説明]
connectの発信ステータス(相手が電話に出たかどうか)をチェックし、
ループ継続or終了の判定を行う為のパラメータ生成を行う
"""
import os
#
import boto3

"""Amazon Connect"""
connect = boto3.client('connect')
instanceId = os.environ['CONNECT_INSTANCE']

def get_attributes(contact_id):
  """発信ステータス取得関数
    Args:
      contact_id(str) : 発信ステータス
    
    Returns:
      call_status(tuple) : 出たかどうかを判別する
  """
  response = connect.get_contact_attributes(
    InstanceId=instanceId,
    InitialContactId=contact_id
  )
  call_status = response['Attributes']['call_status']
  return call_status

def lambda_handler(event, context):
  """Step function接続
    Args:
      example.events = {
        "loop_status": "true",
        "srvname": "field-assistant",
        "altType": "deepsecurity",
        "alertTypePronunciation": "セキュリティーアラート",
        "alert_time_item": "recent_ds_alert_time",
        "contact_id": "eb2e2911-0714-463b-ab0a-4e1e7f8ce0f8",
        "call_times": n,
        "call_status": "unanswered"
      }

    Returns:   
      example.events = {
        "loop_status": "true",
        "srvname": "field-assistant",
        "altType": "deepsecurity",
        "alertTypePronunciation": "セキュリティーアラート",
        "alert_time_item": "recent_ds_alert_time",
        "contact_id": "eb2e2911-0714-463b-ab0a-4e1e7f8ce0f8",
        ***chnage !!! "call_times": n+1,
        "call_status": "unanswered"
      }
  """
  
  call_status = get_attributes(event['contact_id'])
  previouscall_times = event['call_times']
  call_times = int(previouscall_times) + 1
  #
  print('[CallLog]サービス名：'+event['srvname']+', アラート種別：'+event['altType']+', コンタクトID：'+event['contact_id']+', 発信回数：'+str(previouscall_times)+'回目, 発信ステータス：'+call_status)

  response = {
    "loop_status": event['loop_status'],
    "srvname": event['srvname'],
    "altType": event['altType'],
    "alertTypePronunciation": event['alertTypePronunciation'],
    "alert_time_item": event['alert_time_item'],  
    "contact_id": event['contact_id'],
    "call_times": call_times,
    "call_status": call_status
  }

  return response