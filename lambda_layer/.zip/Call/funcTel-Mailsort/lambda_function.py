# -*- coding: utf-8 -*-
##############################################################
# [Lambda関数名]
# funcTel-MailSort
# [説明]
# SESイベントから起動し、送信元アドレス/件名からメールの振分けを行う
# [変更履歴]
# 2019/XX/XX CNW
# 新規作成
##############################################################
#################################
# ライブラリ、モジュールインポート #
#################################
import boto3
import json
import re
import os
import logging
from botocore.exceptions import ClientError

###########
# 定数定義 #
###########
# Zabbixアラート抑止定義を環境変数から取得
calloff_zabbix = os.environ['calloff_zabbix']
# CloudWatchアラーム抑止定義を環境変数から取得
calloff_cloudwatch = os.environ['calloff_cloudwatch']
# Zabbixアラート抑止定義を環境変数から取得
calloff_health = os.environ['calloff_health']

# LAMBDA定義
clientLambda = boto3.client('lambda')
funcName='funcTel-Call'
# SNS送信元メールアドレス
sns_mladdr = r'no-reply@sns.amazonaws.com'
# CloudWatchアラームメール件名検索文字列
chk_alarm = 'ALARM:'
chk_rds = 'RDS'
# Zzbbix(3EaaS含む)アラートメール件名検索文字列
chk_problem = r'PROBLEM'

###########
# 関数定義 #
###########
# Connect連携Lambda起動関数
def launch_call_lambda(srvname, altType, altTypePronunciation):
    # ログ出力
    print('Connect連携Lambdaを起動')

    # Connect連携Lambda起動
    params = {
        "AlertType": altType,
        "AlertTypePronunciation": altTypePronunciation,
        "srv_name": srvname
    }
    res = clientLambda.invoke(
        FunctionName=funcName,
        InvocationType="Event",
        Payload=json.dumps(params)
    )

# メイン関数
def lambda_handler(event, context):
    # SESのイベントオブジェクトから送信元アドレスを取得
    from_mladdr = event['Records'][0]['ses']['mail']['commonHeaders']['from']
    # ログ出力
    print('[Debug：fromアドレス]' + str(from_mladdr))

    # SESのイベントオブジェクトから送信先アドレスを取得
    to_mladdr = event['Records'][0]['ses']['mail']['commonHeaders']['to']
    # ログ出力
    print('[Debug：toアドレス]' + str(to_mladdr))

    # SESのイベントオブジェクトからメール件名を取得
    subject = event['Records'][0]['ses']['mail']['commonHeaders']['subject']
    # ログ出力
    print('[Debug：件名]' + str(subject))

    # 送信先アドレスからサービス名を取得
    to_mladdr_edit = re.search("[\-_0-9a-z]+@biz-cloud.awsapps.com" , str(to_mladdr))
    srvname_arry = to_mladdr_edit.group().split('@')
    srvname = srvname_arry[0]
    # ログ出力
    print('[Debug：サービス名]' + srvname)

    # 抑止対象検索用にサービス名に終端記号としてカンマを付与
    searchSrv = srvname + ','

    # 送信元がSNSであるか判定
    if re.search(sns_mladdr, str(from_mladdr)):
        # 送信元がSNSである場合、件名に'ALARM'or'RDS' が含まれるか判定
        if (chk_alarm in subject) or (chk_rds in subject): 
            # CloudWatchアラームメール処理
            # ログ出力
            print('CloudWatchアラームメール受信')
            # 対象サービスがCloudWatchアラームの抑止対象であるか判定
            if searchSrv in calloff_cloudwatch:
                # アラート抑止対象である場合、処理を終了
                print(srvname + 'はアラート抑止中の為、処理を終了します')
            else:
                # 件名に'ALARM'が含まれる場合、アラート種別に'ClodWatch'を定義
                altType = 'cloudwatch'
                # アラート種別の読みを定義
                altTypePronunciation = 'クラウドウォッチアラーム'
                # Connect連携Lambda関数呼び出し
                launch_call_lambda(srvname, altType, altTypePronunciation)
        elif (chk_problem in subject):
            # Zabbixアラートメール処理
            # ログ出力
            print('Zabbixアラートメール受信')
            # 対象サービスがZabbixアラートの抑止対象であるか判定
            if searchSrv in calloff_zabbix:
                # アラート抑止対象である場合、処理を終了
                print(srvname + 'はアラート抑止中の為、処理を終了します')
            else:
                # 件名に'ALARM'が含まれる場合、アラート種別に'zabbix'を定義
                altType = 'zabbix'
                # アラート種別の読みを定義
                altTypePronunciation = 'ザビックスアラート'
                # Connect連携Lambda関数呼び出し
                launch_call_lambda(srvname, altType, altTypePronunciation)
        else:
            # Healthイベントメール処理
            # ログ出力
            print('Healthイベントメール受信')
            # 対象サービスがHealthイベントの抑止対象であるか判定
            if searchSrv in calloff_health:
                # アラート抑止対象である場合、処理を終了
                print(srvname + 'はアラート抑止中の為、処理を終了します')
            else:
                # 件名に'ALARM'が含まれない場合、アラート種別に'Health'を定義
                altType = 'health'
                # アラート種別の読みを定義
                altTypePronunciation = 'ヘルスイベント'
                # Connect連携Lambda関数呼び出し
                launch_call_lambda(srvname, altType, altTypePronunciation)
    # Zabbixアラートメール処理
    # 送信元がSNSではない場合、対象サービスがZabbixアラートの抑止対象であるか判定
    elif searchSrv in calloff_zabbix:
        # ログ出力
        print('Zabbixアラートメール受信')
        # アラート抑止対象である場合、処理を終了
        print(srvname + 'はアラート抑止中の為、処理を終了します')
    # 対象サービスがアラート抑止対象ではない場合、件名に"PROBLEM"が含まれるか判定
    elif re.search(chk_problem, subject):
        # ログ出力
        print('Zabbixアラートメール受信')
        # メール件名に"PROBLEM"が含まれる場合、アラート種別に'Zabbix'を定義
        altType = 'zabbix'
        # アラート種別の読みを定義
        altTypePronunciation = 'ザビックスアラート'
        # Connect連携Lambda関数呼び出し
        launch_call_lambda(srvname, altType, altTypePronunciation)
    else:
        # ログ出力
        print('Zabbixアラートメール受信')
        # 通知対象メールではない為、処理を終了
        print('通知対象外メールの為、処理終了')
