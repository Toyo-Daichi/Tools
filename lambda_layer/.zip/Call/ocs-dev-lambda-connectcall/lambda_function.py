# -*- coding: utf-8 -*-
"""
[Lambda関数名]
ocs-dev-lambda-connectcall
[説明]
サービス名、イベント種別を判別し、Amazon Connectに発信リクエストを発行する
[変更履歴]
2019/XX CNW ... funcTel-Call-Extended
2021/08 CNW ... ocs-env-lambda-connectcall
"""

import os
#
import boto3
from datetime import datetime
import random
import time

"""Amazon Connect"""
connect = boto3.client('connect')
instanceId = os.environ['CONNECT_INSTANCE']
contactFlowId = os.environ['CONNECT_FLOW']
TimeDifference = os.environ['CONNECT_MIN']
TimeDifference_Sec = float(TimeDifference)*60

"""DynamoDB"""
dynamodb = boto3.resource('dynamodb')
table_name = 'ocs-{}-dynamo-configuration'.format(os.environ['ENV'])
dynamotable = dynamodb.Table(table_name)

"""S3"""
s3 = boto3.resource('s3')
s3UrlParent = 'https://s3.ap-northeast-1.amazonaws.com/'
bucketName = 'ocs-{}-s3-configuration'.format(os.environ['ENV'])
promptDir = 'Prompt/'
prompPrefix = 'Prompt-'
prompSuffix = '.txt'
basePromptFile = promptDir + prompPrefix + 'base' + prompSuffix
#
useCustomPrompt = os.environ['CONNECT_PROMPT']

"""Step Function"""
stepfunctions = boto3.client('stepfunctions')
stateMachineArn = os.environ['STEPFUNCTION_ARN']

"""Function"""
def random_sleep():
  """ランダム待機時間の生成"""
  sleep_time = random.uniform(1,5)
  print('[Debug：ランダム待機]' + str(sleep_time) + '秒待機します')
  time.sleep(sleep_time)

def file_existence_check(file):
  """s3ファイルの存在判別"""
  try:
    s3.ObjectSummary(bucket_name=bucketName, key=file).load()
  except Exception as e:
    return False
  
  return True

def generate_Prompt(promptFile, PromptType, srvNamePronunciation, alertTypePronunciation):
  """プロンプト生成関数
    Args:
      promptFile(str)             : カスタムプロンプトを用いる場合のPATH
      PromptType(str)             : カスタムプロンプトorデフォルトプロンプトを用いるか
      srvNamePronunciation(str)   : サービス名
      alertTypePronunciation(str) : 'セーフ' or 'サービス名のアラート'
  
    Returns:
      message(str) : サービスごとの電話応答メッセージ
  """
  # プロンプトタイプ判定
  if PromptType == 'custom':
    # プロンプトタイプがカスタムの場合
    # S3からプロンプトファイルを読み込み
    resPrompt = s3.Object(bucketName, promptFile)
    rawMessage = resPrompt.get()['Body'].read().decode('utf-8')
    # 読み込んだ内容をそのまま使用する
    message = rawMessage
  elif PromptType == 'base':
    # プロンプトタイプがベースの場合
    # ローカルからプロンプトファイルを読み込み
    with open('./Prompt/Prompt-base.txt') as f:
      rawMessage = f.read()
    # サービス名とアラート種別を置換する
    message = rawMessage.replace('SERVICE-NAME', srvNamePronunciation).replace('ALERT-TYPE', alertTypePronunciation)

  # 
  print('[Debug：プロンプト]')
  print(message)

  return message

def deciding_toNum(item_row, call_times=1):
  """ 発進回数により架電先番号決定
    Args:
      item_row(dict)  : dynamodbから得られた行のdict形式の情報
      call_times(int) : 架電電話番号を決定づける架電回数
    Ruturn:
      toNum(str)      : call_times目で架電する電話番号
    Notes:
      chargeNum(int)      : 各サービスで担当できる人数
      chargeCallNum(int)  : 各サービスで担当者にコールする数
  """
  #exclusion null cell and dict keys to list
  item_row = {key:value for key, value in item_row.items() if value != ''}
  keys = [*item_row.keys()]
  #
  chargeNum = sum('to' in _ for _ in keys)
  chargeCallNum = chargeNum*3
  assignNum = call_times % chargeNum

  if call_times < chargeCallNum:
    if assignNum == 0:
      toNum = item_row["to-num-{}".format(chargeNum)]
    else:
      toNum = item_row["to-num-{}".format(assignNum)]

  else:
    toNum = item_row["to-num-manager"]

  return toNum


def setting_call(srvname, altType, alertTypePronunciation, call_times=1):
  """ 発信設定関数
    Args:
      srvname(str) : service category
      altType(str) : 'safe' or 'service_name'
      altTypePronunciation(str) : 'セーフ' or 'サービス名のアラート'
      *
      call_times(int) : 2回目以降で用いる架電回数

    Returns:
      fromNum(str) : subscribed from Number
      toNum(str)   : subscribed To Number
      message(str) : サービスごとの電話応答メッセージ
  """
  # DynamoDBテーブルから設定情報取得
  # プライマリキー定義
  primary_key = {"name": srvname}
  response = dynamotable.get_item(Key=primary_key)
  # 発信番号取得
  fromNum = response["Item"]['from-num']
  # 着信番号取得
  if call_times == 1:
    toNum = deciding_toNum(response["Item"])
  else:
    toNum = deciding_toNum(response["Item"], call_times=call_times)
  # サービス名(読み)取得
  srvNamePronunciation = response["Item"]['pronunciation']

  # 
  print('[Debug：発信番号]' + fromNum)
  print('[Debug：着信番号]' + toNum)
  print('[Debug：サービス名(読み)]' + srvNamePronunciation)

  # カスタムプロンプト利用有無検索用にサービス名に終端記号としてカンマを付与
  searchSrv =  ',' + srvname + ','
  # カスタムプロンプト使用有無確認
  if searchSrv in useCustomPrompt:
    # カスタムプロンプトを利用する場合はファイルパスを生成
    customPromptFile = promptDir + prompPrefix + srvname + '_' + altType + '_custom' + prompSuffix
    # カスタムプロンプトファイルの存在確認
    if file_existence_check(customPromptFile):
      # カスタムプロンプトファイルが存在した場合のみ使用する
      # 
      print('カスタムプロンプトを使用します')
      # プロンプトタイプを'custom'に定義
      PromptType = 'custom'
      # プロンプト生成
      message = generate_Prompt(customPromptFile, PromptType, srvNamePronunciation, alertTypePronunciation)
    else:
      # カスタムプロンプトファイルが存在しない場合はテンプレートを使用する
      # 
      print('カスタムプロンプトが見つからかった為、テンプレートを使用します')
      # S3からファイルを読み込み
      # プロンプトタイプを'base'に定義
      PromptType = 'base'
      # プロンプト生成
      message = generate_Prompt(basePromptFile, PromptType, srvNamePronunciation, alertTypePronunciation)
  else:
    # テンプレートのプロンプトを使用する
    # プロンプトタイプを'base'に定義
    PromptType = 'base'
    # プロンプト生成
    message = generate_Prompt(basePromptFile, PromptType, srvNamePronunciation, alertTypePronunciation)

  return fromNum, toNum, message

def connect_call(fromNum, toNum, message):
  """Connect連携関数
    Args:
      fromNum(str) : subscribed from Number
      toNum(str)   : subscribed To Number
      message(str) : サービスごとの電話応答メッセージ 

    Returns:
      contact_id(str) : Amazon contact Flow ID
  """
  print('[Debug：発信開始]')

  # Connect呼び出し
  response = connect.start_outbound_voice_contact(
    DestinationPhoneNumber=toNum,
    ContactFlowId=contactFlowId,
    InstanceId=instanceId,
    SourcePhoneNumber=fromNum,
    Attributes={
      'message': message,
      'call_status': 'unanswered'
    }
  )

  # コンタクトIDを取得
  contact_id = response['ContactId']
  # 
  print('[Debug：コンタクトID]' + contact_id)  
  # コンタクトIDを返却
  return contact_id

def update_alert_time(srvname, alert_time_item):
  """アラート受信時刻更新関数
    Args:
      srvname(str)         : service category
      alert_time_item(str) : examaple) 'recent_zbx_alert_time'  

    Notes:
      dynamoDB table update 
  """
  
  # 現在の時刻(unix時間)を取得
  now = datetime.now()
  now_ts = now.timestamp()
  # 
  print('アラート受信時刻を更新します')        

  # DynamoDBテーブル更新用属性名定義
  primary_key = {"name": srvname}
  UpdateExpStr = 'set '+alert_time_item+' = :'+alert_time_item
  ExprAttrStr = ':'+alert_time_item

  # DynamoDBテーブル内の時刻を更新
  response = dynamotable.update_item(
    Key=primary_key,
    UpdateExpression=UpdateExpStr,
    ExpressionAttributeValues={
      ExprAttrStr: str(now_ts)
    }
  )

def start_loop(srvname, altType, alertTypePronunciation, alert_time_item, contact_id, call_status):
  """ループ用ステートマシン起動関数
    Args:
      srvname(str)                  : service category
      altType(str)                  : 'safe' or 'service_name'
      alertTypePronunciation(str)   : 'セーフ' or 'サービス名のアラート'
      alert_time_item(str)          : examaple) 'recent_zbx_alert_time'
      contact_id(str)               : 
      call_status(str)              : 'unanswered' or Number (<3)
    
    Notes:
      Start Stepfunction
  """
  _ = stepfunctions.start_execution(
    **{
      'input' : "{\
        \"loop_status\": \"true\", \
        \"srvname\": \"" + srvname + "\", \
        \"altType\": \"" + altType + "\", \
        \"alertTypePronunciation\": \"" + alertTypePronunciation + "\", \
        \"alert_time_item\": \"" + alert_time_item + "\", \
        \"contact_id\": \"" + contact_id + "\", \
        \"call_times\": 1, \
        \"call_status\": \"" + call_status + "\" \
      }",
      'stateMachineArn' : stateMachineArn
    }
  )

def lambda_handler(event, context):
  """Amazon Connect起動関数
    1st. 初回発信 from 'ocs-dev-lambda-mailcheck'
    Args:
      event(json) : AlertType, AlertTypePronunciation, srv_name
    
    Notes:
      Amazon Connect起動で終了
      #
      example.events = {
        "AlertType": "zabbix",
        "AlertTypePronunciation": "ザビックスアラート",
        "srv_name": "field-assistant"
      }
    
    2nd. StepFunction経由の2回目以降の電話 from Stepfunction
    Args:
      event(json) : loop_status, srvname, altType, alertTypePronunciation, alert_time_item,
                    coontact_id, call_times, call_status
    Notes: 
      example.events = {
        "loop_status": "true",
        "srvname": "field-assistant",
        "altType": "deepsecurity",
        "alertTypePronunciation": "セキュリティーアラート",
        "alert_time_item": "recent_ds_alert_time",
        "contact_id": "eb2e2911-0714-463b-ab0a-4e1e7f8ce0f8",
        "call_times": 1,
        "call_status": "unanswered"
      }
  """

  # 1st cycle
  if not 'loop_status' in event:
    # イベントオブジェクトからアラート種別を取得
    altType_obj = event['AlertType'] 
    altType = str(altType_obj)
    # イベントオブジェクトからアラート種別(読み)を取得
    alertTypePronunciation_obj = event['AlertTypePronunciation']      
    alertTypePronunciation = str(alertTypePronunciation_obj)
    # イベントオブジェクトからサービス名を取得
    srvname_obj = event['srv_name']
    srvname = str(srvname_obj)
  
    print('[Debug：イベント種別]' + altType)
    print('[Debug：イベント種別(読み)]' + alertTypePronunciation)
    print('[Debug：サービス名]' + srvname)

    if altType == 'zabbix':
      alert_time_item = 'recent_zbx_alert_time'
    elif altType == 'cloudwatch':
      alert_time_item = 'recent_cldw_alert_time'
    elif altType == 'health':
      alert_time_item = 'recent_health_alert_time'
    elif altType == 'deepsecurity':
      alert_time_item = 'recent_ds_alert_time'     
    
    # 1～5秒の間でランダムに待機する
    random_sleep()

    # プライマリキー定義
    primary_key = {"name": srvname}
    # DynamoDBテーブルから直近のアラート受信時刻を取得
    response = dynamotable.get_item(Key=primary_key, ConsistentRead=True)
    recentAlertTimeStr = response["Item"][alert_time_item]
    recentAlertTime = float(recentAlertTimeStr)

    # 現在の時刻(unix時間)を取得
    now = datetime.now()
    now_ts = now.timestamp()
    # 現在日時と直近でアラート受信した日時との差(秒)を算出
    diff = float(now_ts) - recentAlertTime
    print('[Debug：時刻差分(秒)]' + str(diff))

    if diff <= TimeDifference_Sec:
      # 時刻差が閾値以下である場合は、DynamoDBテーブル内の時刻を更新し、処理を中断
      update_alert_time(srvname, alert_time_item)
      # 
      print('直近のアラート受領時刻からの経過時間が' + TimeDifference + '分以下の為、処理を中断します')
    else:
      # 時刻差が閾値より大きい場合は、電話番号とプロンプトを取得
      result = setting_call(srvname, altType, alertTypePronunciation)
      # Connect連携関数を呼び出し、コンタクトIDを取得する
      contact_id = connect_call(result[0], result[1], result[2])
      #
      update_alert_time(srvname, alert_time_item)
      call_status = 'open'
      #       
      print('[CallLog]サービス名：'+srvname+', アラート種別：'+altType+', コンタクトID：'+contact_id+', 発信回数：1回目, 発信ステータス：'+call_status)
      start_loop(srvname, altType, alertTypePronunciation, alert_time_item, contact_id, call_status)

  # 2nd later cycle
  else:
    # 発信設定関数を呼び出し、電話番号とプロンプト情報を取得
    result = setting_call(event['srvname'], event['altType'], event['alertTypePronunciation'], call_times=event['call_times'])
    # Connect連携関数を呼び出し、コンタクトIDを取得
    contact_id = connect_call(result[0], result[1], result[2])    
    # DynamoDBテーブル内の時刻を更新
    update_alert_time(event['srvname'], event['alert_time_item'])
    call_status = 'open'
    # 
    print('[CallLog]サービス名：'+event['srvname']+', アラート種別：'+event['altType']+', コンタクトID：'+contact_id+', 発信回数：'+str(event['call_times'])+'回目, 発信ステータス：'+call_status)
    response = {
      "loop_status": event['loop_status'],
      "srvname": event['srvname'],
      "altType": event['altType'],
      "alertTypePronunciation": event['alertTypePronunciation'],
      "alert_time_item": event['alert_time_item'],      
      "contact_id": contact_id,
      "call_times": event['call_times'],
      "call_status": call_status
    }

    return response

  print('Normal END')