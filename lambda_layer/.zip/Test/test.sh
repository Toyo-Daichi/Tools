#!/bin/sh
alias aws='docker run --rm -it -v ~/.aws:/root/.aws -v /home/toyo/:/aws amazon/aws-cli'

get_table_data() {
  aws dynamodb describe-table --table-name ${original_table_name} > ${original_table_file}

  cat ${original_table_file} |
  jq '.Table' |
  jq '.TableName = "'${new_table_name}'"' |
  jq 'del(.TableStatus)' |
  jq 'del(.CreationDateTime)' |
  jq 'del(.ProvisionedThroughput.LastIncreaseDateTime)' |
  jq 'del(.ProvisionedThroughput.NumberOfDecreasesToday)' |
  jq 'del(.TableSizeBytes)' |
  jq 'del(.ItemCount)' |
  jq 'del(.TableArn)' |
  jq 'del(.TableId)' |
  jq 'del(.LatestStreamLabel)' |
  jq 'del(.LatestStreamArn)' |
  jq 'del(.GlobalSecondaryIndexes[]?.IndexStatus)' |
  jq 'del(.GlobalSecondaryIndexes[]?.IndexSizeBytes)' |
  jq 'del(.GlobalSecondaryIndexes[]?.ItemCount)' |
  jq 'del(.GlobalSecondaryIndexes[]?.IndexArn)' |
  jq 'del(.GlobalSecondaryIndexes[]?.ProvisionedThroughput.NumberOfDecreasesToday)' > ${new_table_file}
}

create_table() {
  aws dynamodb create-table --cli-input-json file://${new_table_file}
}

get_items_data() {
  aws dynamodb scan --table-name ${table_name} > ${original_items_file}
}

put_items() {
  item_length=$(cat ${original_items_file} | jq ".Items | length")

  if [ ${item_length} -gt 0 ]; then
    for i in $( seq 0 $((${item_length} - 1)) ); do
      item=$(cat ${original_items_file} | jq ".Items[${i}]")
      aws dynamodb put-item --table-name ${new_table_name} --item "${item}" --endpoint-url http://localhost:8000
    done
  fi
}

target_tables=("ToyookaHandsOn")

for table_name in ${target_tables[@]}; do
  # テーブル名
  original_table_name=${table_name}
  new_table_name=${original_table_name}_copy

  # テーブル定義ファイル名
  original_table_file=original_table_${original_table_name}.json
  new_table_file=new_table_${new_table_name}.json

  # アイテム情報ファイル名
  original_items_file=original_items_${original_table_name}.json

  get_table_data
  create_table
  get_items_data
  put_items
done