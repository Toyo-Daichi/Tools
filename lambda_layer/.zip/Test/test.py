# -*- coding: utf-8 -*-

def hello():
	print("Normal END")

hello()
