#!/bin/sh

a=`head -c 10 /dev/urandom | base64 | tr -dc 'a-zA-Z0-9' | cut -c 1-10`

echo $a
