// ■文字列関数
// https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/String

const paragraph = 'The quick brown dog jumps over the lazy dog. It barked.';

//indexOf
// 文字列の中に、特定の文字が含まれているかどうかをチェックします。
console.log(paragraph.indexOf('dog'))
// 16文字目にあることがわかる。ない場合は-1が戻る
// 16

//replaceAll
// 文字を置き換えて、新しい文字列を生成します（元の文字列はこわれません）
console.log(paragraph.replaceAll('dog','cat'))

//split
// 文字列を、指定の文字で区切って配列を生成します。元の文字列はこわれません）
console.log(paragraph.split('dog'))
// dogを区切り文字として、要素が３つの配列に変換する
// ["The quick brown ", " jumps over the lazy ", ". It barked."]

//match
// 正規表現という書式を用い、指定の文字列が、正規表現ルールにマッチしているかどうかをチェックします。
// フォームに内容が入っているか、とか、英数小文字8文字以下とかのバリデーションは、この機能を使っています。
// 現時点ではスキップします。
const regex = /[A-Z]/g;
const found = paragraph.match(regex);
// 文字列の中にアルファベット大文字が入っているかどうかを確認している
// expected output: Array ["T", "I"]




let arr=[
    {'name':'山田',age:23},
    {'name':'鈴木',age:25},
    {'name':'武田',age:21}
 ]
 arr.map((e,i,a)=>{return {'age':e.age*2}})


 let arr=[
    {'name':'山田',age:23},
    {'name':'鈴木',age:25},
    {'name':'武田',age:21}
 ]
 arr.filter((e,i,a)=>{
     return e.age==25
 })
 