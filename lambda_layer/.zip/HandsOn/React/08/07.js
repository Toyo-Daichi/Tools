
// １：if、if-else、if-elseif-else
//単一のif
let a='aaa'
if(a==='aaa'){　　//等価判断は、最近のJavascriptでは基本===で行います。
    // aがaaaの場合
    console.log('aはaaaでした')
}

//if-else
let a
a='aaa'
a='aaaa'
if(a==='aaa'){　　//等価判断は、最近のJavascriptでは基本===で行います。
    // aがaaaの場合
    console.log('aはaaaでした')
}else{
　　// それ以外
    console.log('aはaaaではなかった')
}

//if-elseif-else
let a
a='aaa'
a='bbb'
a='aaaa'
if(a==='aaa'){　　//等価判断は、最近のJavascriptでは基本===で行います。
    // aがaaaの場合
    console.log('aはaaaでした')

}else if(a==='bbb'){
    console.log('aはbbbでした')
}else{
　　// それ以外
    console.log('aはaaaではなかった')
}

// ２：単一条件
// aがaaaの場合
let a='aaa'
if(a === 'aaa'){
    console.log(a)
}

// aがaaaではない場合
let a='bbb'
if(a !== 'aaa'){
    console.log(a)
}

// 数値の比較も可能
// 慣例的に、小さいものは左側に書くように心がける（不等号の向きが統一され、混乱しにくい）
// 3より大きい
let a=4
if(3 < a){    // a > 3 とも書けるが、書かない
    console.log(a)
}
// 3以上
let a=4
if(3 <= a){
    console.log(a)
}

// その他

//配列の要素数
let arr=[1,2,3,4,5]
// 配列の要素数が3以下だったら
if( arr.length < 3 ){
    console.log(arr)
}

//関数との組み合わせ
let mail = 'aaaa@gmail.com'
// メールアドレスのドメインに、特定の文字列が入っていたら（文字列関数は後で解説します）
if( mail.indexOf('gmail')>-1 ){
    console.log(mail)
}




// ３：複合条件（AND、OR）
// AND条件
//aがaaa かつ、 bがbbbだったら
let a='aaa'
let b='bbb'
if(a==='aaa' && b==='bbb'){
    //どちらの条件も適合した
    console.log(a)
    console.log(b)
}

// OR条件
//aがaaa または、 bがbbbだったら
let a='aaa'
let b='ccc'
if(a==='aaa' || b==='bbb'){
    // a==='aaa'だけ適合した
    console.log(a)
    console.log(b)
}

let a='aab',b='bbb',c='ccc';
// ANDとORの複合
//（）をつけることで、式の評価の優先順位が変わるので注意する！
// aがaaa かつ、（bがbbbまたはcがccc）の場合
if( a==='aaa' &&  ( b==='bbb' || c==='ccc') ){

    // ここに入るパターンは
    // a===aaa b===bbb
    // a===aaa c===ccc
    // のどちらかとなる。

    console.log('hit')
}
// （）がない場合、式の評価が変わってしまう
// aがaaaかつbがbbb または、 cがccc
if( a==='aaa' && b==='bbb' || c==='ccc' ){

    // ここに入るパターンは
    // a===aaa b===bbb
    // c===ccc
    // のどちらかとなる。

    console.log('hit')
}