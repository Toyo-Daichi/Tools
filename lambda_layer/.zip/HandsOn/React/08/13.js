// ■async await

//まず、普通に書いていれば、それは自動で同期処理になります。
//その行の処理が終わってから、次に進む
{
  console.log('a');
  console.log('b');
  console.log('c');
}
// a
// b
// c

//次に、非同期処理を書きたい場合、async functionの中で定義します。
{
  // 3秒掛けて、JSONデータをAPIで取得する関数（仮
  function fetchData() {
    //このPromiseを内部的に返す関数は、非同期関数になります。
    return new Promise((resolve) => { setTimeout(() => {
      resolve('{"result":"吉です"}')
    }, 3000); });
  }

  //この下の即時関数は、非同期として処理される
  (async () => {
    // awaitを書いて、非同期関数が終わらないと、次の行に進めないようにします
    // （必ずresultに結果が入ってから、次の行に進む）
    const result = await fetchData();
    const obj=JSON.parse(result)
    console.log(obj.result)
  })();
  //時間の掛かる非同期処理より、console.logが先に処理される
  console.log('今日の運勢は');
}
// 今日の運勢は
// (3秒くらい経過してから）
// 吉です！

//非同期処理で同期処理a,dを実行します。
{
  //1~3秒掛けて、JSONデータをAPIで取得する関数（仮
  function fetchData() {
    const random= Math.floor(Math.random() * 2)
    return new Promise((resolve) => { setTimeout(() => {
      //ランダムに運勢を返す
      const result=['大吉','中吉','小吉'][random]
      resolve(`{"result":"${result}です"}`)
      //1,2,3秒いずれか秒後に値を返却する
    }, [1000,2000,3000][random]); });
  }
  (async () => {
    const a=JSON.parse(await fetchData())
    const b=JSON.parse(await fetchData())

    console.log(`今日は${a.result} ,明日は${b.result}`)
  })();
  console.log('今日と明日の占いを表示します');
}
// 今日の運勢は
// (1~3秒くらい経過）
// (1~3秒くらい経過）
// 今日は$小吉/中吉/大吉 ,明日は$小吉/中吉/大吉です！

// a,bを同期で処理する必要はないので(APIリクエスト２回分待たせている）
// この二つは並列で処理させても良く、その場合は次のサンプルが参考になります。

// a,b,cを並列に非同期処理を行い、全て完了したら出力処理を行う。
{
  //1~3秒掛けて、JSONデータをAPIで取得する関数（仮
  function fetchData() {
    //0,1,2のどれかを返す
    const random= Math.floor(Math.random() * 3)
    return new Promise((resolve) => { setTimeout(() => {
      //ランダムに運勢を返す
      const result=['大吉','中吉','小吉'][random]
      resolve(`${result}です`)
      //1,2,3秒いずれか秒後に値を返却する
    }, [1000,2000,3000][random]); });
  }

  const tasks= async () => {
    const [a, b, c] = await Promise.all(
      [
        fetchData(),
        fetchData(),
        fetchData()
      ]
    );
    return [a, b, c]
  }

  //a,b,c全ての処理が完了したら・・
  tasks().then(([a, b, c]) => {
    //出力処理を行う。
    console.log(a, b, c); // => 5 10 20

    //並列でない場合、全てのJSONデータが返却に3秒かかる場合、3秒＋3秒＋3秒で９秒掛かるが
    //並列に実行する場合、最大３秒で返却される。

  });
}