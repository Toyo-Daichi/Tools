// ■オブジェクトのループ
// for inは使ってはいけないので注意

let a = { a: 0, b: 1, c: 2 };

//基本はこれ。
// break,continueも可能です
for(let key of Object.keys(a)) {
    console.log(a[key]);
}
// 0
// 1
// 2
// または
// 1
// 2
// 0
// の’可能性がある’（以後、可能性は記載しません）

// forEachも可能
Object.keys(a).forEach((key)=>{
    console.log(a[key]);
});
// 0
// 1
// 2



// 課題2
const API_RECEIVED_DATA='{"schoolData":[{"name":"a-school","location":"tokyo","teacher":"yamada katsumi","students":[{"name":"takada tatsuya","age":14,"weight":50},{"name":"suzuki shinya","age":15,"weight":52}]},{"name":"b-school","location":"shimane","teacher":"sato masaki","students":[{"name":"shimizu ai","age":18,"weight":42},{"name":"kaneko tomohiro","age":23,"weight":58}]},{"name":"c-school","location":"aomori","teacher":"yamamoto kana","students":[{"name":"ito tomohiro","age":16,"weight":48},{"name":"shimizu yoshie","age":17,"weight":47}]}]}'

const data=JSON.parse(API_RECEIVED_DATA)


for (const node of data.schoolData) {
    console.log(node.name)
}


for (const node of data.schoolData) {
    for (const student of node.students) {
        console.log(student.name)
    }
}