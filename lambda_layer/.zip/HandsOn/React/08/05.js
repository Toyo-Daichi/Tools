// ■ループ（配列）
let a = ['AAA', 'BBB', 'CCC'];

// １：forを使用したループ
// 昔からあるforループ。他の言語でも存在する、基本的なループです
// [i]には、index(配列の何番目か)の数字が入ります
for(let i = 0; i < a.length; i++) {
    console.log(a[i]);
}
// AAA
// BBB
// CCC

// 余談ですが、こう書くと100回AAAって表示します
for(let i = 0; i < 100; i++) {
    console.log(i+':aaa');
}

//breakの説明
for(let i = 0; i < a.length; i++) {
    if(a[i]==='BBB'){
        // breakを書くと、ループを強制終了できる
        break;
    }
    console.log(a[i]);
}
// AAA

// continueの説明
for(let i = 0; i < a.length; i++) {
    if(a[i]==='BBB'){
        // continueを書くと、次のループに強制移動します
        continue;
    }
    console.log(a[i]);
}
// AAA
// CCC

// ２：for ofを使用したループ
// indexがいらない場合は、基本これを使います。
// break,continueも可能です
for (const node of a) {
    console.log(node);
}
// AAA
// BBB
// CCC

// ３：array.forEachを使用したループ
//上述のようなbreak,continueは使えないので注意
let a = ['AAA', 'BBB', 'CCC'];
a.forEach((element,index,array) => {
    //element 値
    //index インデックス
    //array 配列全体
    console.log(element)
});
// AAA
// BBB
// CCC

a.forEach((element,index,array) => {
    if(element==='AAA'){
        console.log(element)
    }
});
// AAA
// ただし、3回ループはしてしまうので
