//データ型
let a = 1; // 1(数値型)
console.log(a)
let h = 1 + 2; // 3(数値型)
console.log(h)
let b = 'abcde'; // 'abcde'(文字列型)
console.log(b)
let c = '1'; // '1'(文字列型)（クォートで囲んでいる為）
console.log(c)
let d = '2'; // '2'(文字列型)（クォートで囲んでいる為）
console.log(d)
let h = 1 + 'a'; // '1a'(文字列型)（数字と文字列を繋げた場合、文字列扱いになる）
console.log(h)
let e = 1 + '+a'; // '1+a'(文字列型)
console.log(e)
let g = true; // true(真偽型)
console.log(g)
