
//基本パターン
// -----------------------------------------------
//関数の定義
function aaa(param) {
    //paramという数字をもらい、２倍にする
    let sum = param * 2
    //２倍の値を返却する。
    return sum
}


function aaa(param1,param2) {
    let result = param1 - param2
    return result
}

function aaa(param1,param2) {
    return param1 - param2
}

const aaa = (p1,p2)=>(p1-p2)




//実行部分
let sum;
//param引数に3を入れて、aaaを呼び出す。6が戻り値として返却される
sum=aaa(3)
console.log(sum) //6

//param引数に12を入れて、aaaを呼び出す。24が戻り値として返却される
sum=aaa(12)
console.log(sum) //24

// -----------------------------------------------
// 返却が無ければ、returnは書かなくても良い。
function aaa(param) {
    //paramという文字をconsoleに出力する
    console.log(param)
}
aaa(3)　//consoleに3と出るだけ

// -----------------------------------------------
// 引数は２個でもよい
function aaa(param,param2) {
    //paramという文字をconsoleに出力する
    console.log(param,param2)
}
aaa(3,5)　//consoleに3,5と出るだけ

// -----------------------------------------------
// 引数はなくてもよい
function aaa() {
    //helloという文字をconsoleに出力する
    console.log('hello')
}
aaa()　//consoleにhelloと出るだけ

// -----------------------------------------------
// 返却値は配列でもOK
function aaa(param,param2) {
    return [param,param2]
}

// 返却値はオブジェクトでもOK
function aaa(param,param2) {
    return {
        'param':param,
        'param2':param2
    }
    //短縮表記（sugar syntax)で同じ内容をシンプルに記述できます。
    // return {param,param2}
}

// -----------------------------------------------
// 関数の定義方法が複数存在します。
// １，２，３は全てaaa(2)のような形で呼び出せる

//１：関数宣言
function aaa(value) {
    return value
}

//２：関数式宣言
const aaa = function(value){
    return value
}

//３：関数式宣言(アロー式)
const aaa = (value) => value
//３a 複数コマンドのアローは、中括弧が必要
const aaa = (value) => {
    console.log(value)
    return value
}

//４：オブジェクトのプロパティとしての宣言
//（この場合、fn.aaa(2)という呼び出し方になる）
const fn = {

    //古い書き方
    aaa:(value)=>{return value},
    //新しい書き方
    bbb(value){return value}
}
// -----------------------------------------------
// 即時関数（とても重要）
// 関数を定義し、即時実行する。変数を用意したりしなくて良くなる

//原型
const aaa = (value) => value*2
//3を引数に実行すると、6が返ってくる
aaa(3) //6が返ってくる

//これは、下記と同じ
//１：その場で関数を宣言
//２：丸括弧で囲む（こういう変数だよ、ということにする）
//３：後ろに丸括弧をつける（引数を付けて実行する）
//↓↓↓↓↓↓↓↓↓↓↓↓↓↓
((value) => value*2)(3)

//引数が不要な即時関数だとこういった書き方になります。括弧が多くて解りにくくなるので注意
//実行するとhelloが返ってくる関数
(()=>'hello')()
