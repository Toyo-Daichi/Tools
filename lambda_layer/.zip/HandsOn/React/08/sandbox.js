(()=>{

    //function define
    const fn={
        init(){
            // console.log('init');
            //debugger;

        }
    }

    //init
    fn.init();

})();