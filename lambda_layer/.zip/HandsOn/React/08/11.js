// ■スコープ
// 中括弧で囲まれた部分を指します。
//内から外は参照できますが、外から内は参照できません。

{
    const a=1
    {
        const b=2
        console.log(a)  // 1
        console.log(b)  // 2
    }
    console.log(a) // 1
    console.log(b) // undefined!!
}

// ■グローバル変数
// 括弧より外に書いたものは、グローバルスコープといい、どこからでも参照が可能ですが
// 参照範囲がとても広くなってしまうので、できるだけ使用は控えるべきです。
// 知らないうちに書き換えがされる場合があります。（スコープの汚染といいます）

//ここのscriptとscript2は、index.htmlの中でscript.js,script2,jsを読み込むようにコメントアウトを解除し
// コードを貼り付けて、実行してみてください

//■良くない例その１：別ファイルなのに、変数を参照できてしまう。
//------------------------------------------------------------------------------
// ./script/script.js
//-------------
let test='hello'
//-------------

// ./script/script2.js
//-------------
console.log(test) //hello
//------------------------------------------------------------------------------

//■良くない例その２：たまたま同じ関数の名前を使っていると、上書きされてしまう
//------------------------------------------------------------------------------
// ./script/script.js
//-------------
function aaa(){console.log('Hello')}　//aaaを定義している
setTimeout(()=>aaa(),2000) //２秒経過したらaaaを実行する
//2秒後にaaaが実行されるが、実行するころには、aaaははscript2で上書きされているので
//Bye-Byeが表示される

// ./script/script2.js
//-------------
function aaa(){console.log('Bye-Bye')}　//同名のaaaを定義している
aaa() //Bye-Bye　//
//------------------------------------------------------------------------------

//■クロージャとは
// スコープを活用した関数の宣言を行い、スコープの汚染を防ぐ試みです。

// このカウントを行う関数と変数のセットは、スコープ内に記述されているため
// 外部から変数や関数を上書きすることができません。
// また、参照しているcounterは保持されつづける為、毎回0にリセットされることもなく
// 加算され続ける。
//
// 値を保持する機能と、カウントを行う機能で、一つのモジュールとして構築できています。
(()=>{
    //カウントを行う変数
    let counter=0;
    //500ミリ秒毎に、カウンタを＋１してconsole.logで表示する
    setInterval(()=>console.log(counter++),500)
})();

// counter変数の外部からのアクセスを禁止するが、plusCounter,minusCounterは許可する。
// これも、値を保持する機能と、カウントの増減を行う機能を、一つのモジュールとして構築できています。
{
    const kitchenCounterModule= ()=>{
        //カウントを行う変数
        let kitchenCounter=0;

        // constとreturnの宣言
        const plusCounter=()=>++kitchenCounter;
        const minusCounter=()=>--kitchenCounter;
        const showCounter=()=>kitchenCounter;

        //10.jsで使っていた短縮表記
        return { plusCounter,minusCounter,showCounter}

        // 短縮表記を使わない場合、こう書く
        // return {
        //     plusCounter:plusCounter,
        //     minusCounter:minusCounter,
        //      showCounter:showCounter
        //  }

        // このconstとreturnの宣言は、まとめてこのように書いても良い：
        // return{
        //     plusCounter(){
        //         return ++kitchenCounter
        //     },
        //     minusCounter(){
        //         return --kitchenCounter
        //     },
        //     showCounter(){
        //         return kitchenCounter
        //     }
        // }

    }

    //関数定義終わり、ここから実行
    const timer=kitchenCounterModule()
    timer
    timer.plusCounter()
    console.log(timer.showCounter())// 1

    timer.plusCounter()
    console.log(timer.showCounter())// 2

    timer.minusCounter()
    console.log(timer.showCounter())// 1
}
// このように、機能毎にスコープを設けて、変数や関数の参照範囲をきちんと管理する仕組みを
// モジュール化と呼びます。
// 現在はモジュール化の仕組みはもう少し進歩していますが
// クロージャと、基礎的なモジュール化は細かい実装でも使っていきますので、是非覚えておきましょう
