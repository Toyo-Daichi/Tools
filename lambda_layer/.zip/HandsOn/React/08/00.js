//let宣言
// let宣言（変数：後から変更可能）
{
let a = 1;
console.log(a); // 1
let a = 2; //これはエラー。同じスコープで宣言は一度だけ
a = 2; // aに2を再代入
console.log(a); // 2
}

{
// const宣言（定数：変更不可）
const a = 1;
console.log(a); // 1
const a = 2; // これはエラー。変更不可
a = 2; //これもエラー。変更不可
}

//「var」宣言
//（緩いlet宣言）も使えましたが、現在は非推奨となっています
