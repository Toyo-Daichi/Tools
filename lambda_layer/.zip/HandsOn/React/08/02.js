// ■オブジェクト型
let a = { a: 0, b: 1, c: 2 }; //同じ階層で、キーの重複は禁止
console.log(a); // {a: 0, b: 1, c: 2}
// この「a,b,c」の順番は保証されているわけではないので注意

// 下の3つは全て同じ0を示す。
// (１つ目はキーの名前を固定している。３個目は、変数を使用して、適用するキーを自由に変更できることを示す)
// ------------------------
console.log(a.a); // 0
console.log(a['a']); // 0
let b = 'a';
console.log(a[b]); // 0
// ------------------------

let c = { a: 0, b: 'aaaa', c: true }; //値は型の指定が無く、自由に代入可能

let d = { a: 0, b: 'aaaa', c: { a: true } }; //オブジェクト型にオブジェクト型を重ねる（ネスト）ことが可能
console.log(d.c.a); // true

d.c.a = false; //オブジェクト内の一部の値を書き換えることも可能
console.log(d.c.a); // false
console.log(d); // {a: 0, b: "aaaa", c: {a:false}}

d.c.b = '1111' //新規にキーを付け足すことも可能
console.log(d); // {a: 0, b: "aaaa", c: {a: false, b: "1111"}}

delete d.c.b // 今作成したd.c.bだけ削除
console.log(d); // {a: 0, b: "aaaa", c: {a: false}

console.log(Object.keys(d).length) //3  その階層のキーの数が取得できる