// ■配列関数
// 山ほどありますが、私が実業務で使っているものをピックアップします。
// https://developer.mozilla.org/ja/docs/Web/JavaScript/Reference/Global_Objects/Array

let arr=[1,3,5,2,4]
// pop,shift,spliceは以前紹介しているので、スキップします

//sort
// 配列をソートして置き換えます。
// デフォルトは昇順ソートですが、逆順にソートすることも可能です。（ここでは割愛します）
console.log(arr.sort())
//[1, 2, 3, 4, 5]

//reverse
//配列を逆順に並び替して置き換えます。
console.log(arr.reverse())
// [5, 4, 3, 2, 1]

//join
//配列の要素を結合して、一つの文字にします。
console.log(arr.join())
// 5,4,3,2,1

// 余談ですが、区切り文字を指定も可能です。
// CSVファイルの生成(カンマ区切り)や、文字列の結合に使用します。
console.log(arr.join('と'))
// 1と3と5と2と4

let arr=[1,3,5,2,4]
// indexOf
// 配列の中に目的の要素があるかどうかを検索します。
// ない場合は-1が戻り、ある場合は、該当する要素が存在したインデックスを返します。
console.log(arr.indexOf(10))
// -1
console.log(arr.indexOf(2))
// 3

// ■ES5からの関数

let arr=[
    {'name':'山田',age:23},
    {'name':'鈴木',age:25},
    {'name':'武田',age:21}
]
// map()
// 名前だけの配列にする
console.log(arr.map((e,i,a)=>e.name))
// 配列がどう変化したか、が重要なので、ここではconsole.logの出力内容を配列にしています。
// ["山田", "鈴木", "武田"]

// 余談ですが、ここにforeachをチェインすれば文字列として出力できます。
// (map関数は戻り値があるが、foreEach関数は戻り値が無いので、全体をconsole.logで囲むことができません)
arr.map((e,i,a)=>e.name+'さん').forEach((e,i,a)=>console.log(e))
// 山田さん
// 鈴木さん
// 武田さん

// filter()
// 「'山田'が名前に入っている」オブジェクトだけフィルタする
console.log(arr.filter((e,i,a)=>e.name==='山田'))
// [ {'name':'山田',age:23} ]

// 余談ですが、戻ってきた配列の0番目のnameにアクセスすれば、「山田」だけ取得できます
console.log(arr.filter((e,i,a)=>e.name==='山田')[0].name)
// 山田

// 余談ですが、「名前に'田'を含む」のような条件でフィルタすることもできます
console.log(arr.filter((e,i,a)=>e.name.indexOf('田')>-1))
// [ {'name':'山田',age:23},{'name':'武田',age:21} ]

// 余談ですが、「名前に'田'を含む」かつ「年齢が22歳以下」みたいなことも可能です
console.log(arr.filter((e,i,a)=>e.name.indexOf('田')>-1 && e.age>=22))
// [ {'name':'山田',age:23} ]

// reduce()
// 使用頻度は低めです
// 配列ごとの処理内容を、次の配列に渡します（累積）
// 一度単一要素（名前だけの配列）にしてから、reduceに渡します
console.log(arr.map((e,i,a)=>e.name).reduce((accumulator,currentValue)=> accumulator+'と、'+ currentValue))
// 山田と、鈴木と、武田