
// javascript形式のオブジェクト→JSON形式に変換
let a={'aaa':000}
let b= JSON.stringify(a)
console.log(b) // {"aaa":0}  という文字になっている

let c= JSON.parse(b)
console.log(c)  // {aaa: 0}　Javascriptオブジェクトになっている

// 課題1
const API_RECEIVED_DATA='{"schoolData":[{"name":"a-school","location":"tokyo","teacher":"yamada katsumi","students":[{"name":"takada tatsuya","age":14,"weight":50},{"name":"suzuki shinya","age":15,"weight":52}]},{"name":"b-school","location":"shimane","teacher":"sato masaki","students":[{"name":"shimizu ai","age":18,"weight":42},{"name":"kaneko tomohiro","age":23,"weight":58}]},{"name":"c-school","location":"aomori","teacher":"yamamoto kana","students":[{"name":"ito tomohiro","age":16,"weight":48},{"name":"shimizu yoshie","age":17,"weight":47}]}]}'

//
let str=JSON.parse(API_RECEIVED_DATA)
console.log(str.schoolData[0].teacher)

//
console.log(str.schoolData[1].students[1].weight)

//
console.log(str.schoolData.length)

//
//for (let index=0; index <= 2; index++){console.log(str.schoolData[index].name)}
//for (let index=0; index <= 2; index++){for (iindex=0; iindex<=1; iindex++) {console.log(str.schoolData[index].students[iindex].name)}}

// 1
for (let index=0; index<=2; index++){
  console.log(string.schoolData[index].name)
}

// 2
for (let _x=0; _x<=2; _x++){
  for (let _y=0; _y<=1; _y++){
    console.log(string.schoolData[_x].students[_y].name)   
  }
}

//for (let _x=0; _x<=string.schoolData.length-1; _x++){
//  for (let _y=0; _y<=string.schoolData[0].students.length-1; _y++){
//      console.log(string.schoolData[_x].students[_y].name)   
//  }
//}