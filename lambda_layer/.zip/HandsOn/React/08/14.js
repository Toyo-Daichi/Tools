// GET
// 公開されている、天気予報APIからデータを取得します。
{
  try {
    (async () => {
      let url = 'https://www.jma.go.jp/bosai/forecast/data/overview_forecast/130000.json';
      // fetchは非同期処理なので、非同期処理内でawaitを使用する
      const response = await fetch(url);
      // json()メソッドも同様。
      const data = await response.json();
      console.log(JSON.stringify(data));
    })();
  } catch (error) {
    console.log(e)
  }
}

// POST
// これは実行できません。サンプルとしてイメージを掴んで下さい。
{
  try {
      // fetchは非同期処理なので、非同期処理内でawaitを使用する
    const response = await fetch(`http://xxxx:9000/api/sensors/`, {
      //POSTメソッドを選択
      method: 'POST',
      //送信するデータをJSON形式で指定
      body: JSON.stringify({ question1: 1, question2: 2 }),
    });
    // 大抵は、「送信が成功したかどうか」のデータが返ってくるので、内容により処理を分けたりする
    const data = await response.json();
    console.log(data);
  } catch (error) {
    console.log(e)
  }
}
