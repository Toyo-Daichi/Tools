//■タイマー

// SetInterval/ClearInterval関数
// 定期実行を開始・停止する。
{
  // タイマーIDを記録する
  let timerId = 0;
  // カウンタを記録する
  let counter = 0;

  // 1000ミリ秒（１秒）ごとに定義された関数を実行する
  timerId = setInterval(() => {
    console.log(++counter);
    // カウント5になったら
    if (counter == 5) {
      // タイマー停止
      clearInterval(timerId);
    }
  }, 1000);
}
// １秒経過してから
// 1
// １秒経過してから
// 2
// １秒経過してから
// 3

// SetTimeOut/ClearTimeOut関数
// 遅延実行を開始・停止する。
{
  // タイマーIDを記録する
  let timerId = 0;
  // 10秒経過したら、一度だけ定義された関数を実行する
  timerId = setTimeout(function () {
    console.log('実行');
  }, 10000);

  // 10秒以内に下記の関数が実行された場合、setTimeOutは実行されない。
  // clearInterval(timerId);
}
// １０秒経過してから
// 1