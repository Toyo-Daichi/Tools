function aaa(){console.log('Bye-Bye')}　//同名のaaaを定義している
aaa() //Bye-Bye　//