# Udemy for Business

### 内容
- HTML-CSS フロントエンドエンジニアになりたい人のWebプログラミング入門  
  FROM: Udemy
  URL: https://nttls.udemy.com/course/html-css-js/learn/lecture/24652422#  
  使用言語: `html`, `css`, `javascript`
  Directory: `HTML-CSS`

- AWS
  FROM: AWS Official Reference
  使用言語: `python`, `Node.js`
  Directory: `AWS` 

### 作成情報
開始日: 2021/7/20
